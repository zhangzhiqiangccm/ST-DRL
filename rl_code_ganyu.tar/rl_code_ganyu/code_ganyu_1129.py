import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from scipy.stats import norm, gaussian_kde
from collections import defaultdict
import matplotlib.gridspec as gridspec
from math import pi

# ==========================================
# 0. Global Setup & Style
# ==========================================
SEED = 2025
np.random.seed(SEED)

OUTPUT_DIR = "ST_DRL_Final_Submission"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# Top-Tier Journal Style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_context("paper", font_scale=1.5)
# Font configuration (Fallbacks for compatibility)
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans', 'SimHei']
plt.rcParams['lines.linewidth'] = 2.5
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.constrained_layout.use'] = True 

# Unified Color Palette
PALETTE = {
    'No Intervention': 'black',
    'Random': 'gray',
    'Static Degree': '#95a5a6', # Grey
    'PageRank': '#34495e',      # Dark Slate
    'Dynamic Degree': '#9b59b6',# Purple
    'ST-DRL w/o Time': '#3498db', # Blue
    'ST-DRL': '#e74c3c'         # Red
}

# ==========================================
# 1. Core Logic: Environment
# ==========================================

class TemporalDynamics:
    def __init__(self, duration=72, event_time=35):
        self.hours = np.linspace(0, duration, duration * 4)
        self.sim_steps = duration
        self.event_time = event_time
        
        self.profiles = {
            0: self._gen_rhythm([23], [3]),       # Youth
            1: self._gen_rhythm([8, 19], [2, 2]), # Workforce
            2: self._gen_rhythm([7], [2]),        # Elder
            3: self._gen_noise_rhythm()           # Bots
        }
        self.event_signal = norm.pdf(self.hours, loc=event_time, scale=2.5)
        self.event_signal /= (self.event_signal.max() + 1e-9)

    def _gen_rhythm(self, peaks, scales):
        y = np.zeros_like(self.hours)
        for day in [0, 1, 2]:
            for p, s in zip(peaks, scales):
                y += norm.pdf(self.hours, loc=p + day*24, scale=s)
        y /= (y.max() + 0.01)
        return y
    
    def _gen_noise_rhythm(self):
        return np.random.uniform(0.3, 0.5, size=len(self.hours))

    def get_step_params(self, step, group_ids):
        t_idx = int((step / self.sim_steps) * len(self.hours))
        t_idx = min(t_idx, len(self.hours)-1)
        psi = self.event_signal[t_idx]
        
        beta_factor = 1.0 + 2.5 * psi 
        
        probs = np.zeros(len(group_ids))
        for gid in np.unique(group_ids):
            mask = (group_ids == gid)
            base = self.profiles[gid][t_idx]
            sensitivity = 0.8 if gid != 3 else 0.1
            probs[mask] = np.clip(base + sensitivity * psi, 0.01, 0.98)
        return probs, beta_factor, psi

class SocialEnvironment:
    def __init__(self, n_nodes=300, beta_base=0.25, budget=5):
        self.n_nodes = n_nodes
        self.beta_base = beta_base
        self.budget = budget
        self.gamma = 0.1
        self.max_steps = 72
        
        # Power-law Cluster Graph
        self.G = nx.powerlaw_cluster_graph(n=n_nodes, m=4, p=0.1, seed=SEED)
        self.degrees = np.array([d for _, d in self.G.degree()])
        self.pagerank = np.array(list(nx.pagerank(self.G).values()))
        self.groups = np.random.choice([0, 1, 2, 3], size=n_nodes, p=[0.3, 0.4, 0.2, 0.1])
        
        self.dynamics = TemporalDynamics(duration=self.max_steps)
        
    def reset(self):
        self.state = np.zeros(self.n_nodes)
        seeds = np.concatenate([
            np.where(self.groups==3)[0][:6], 
            np.random.choice(range(self.n_nodes), 4)
        ])
        self.state[seeds] = 1
        self.curr_step = 0
        self.history = {'infected': [], 'actions': []}
        return self._get_obs()

    def _get_obs(self):
        probs, beta_fac, psi = self.dynamics.get_step_params(self.curr_step, self.groups)
        return self.state, probs, beta_fac, psi

    def step(self, action_nodes):
        state, probs, beta_fac, psi = self._get_obs()
        is_active_truth = np.random.rand(self.n_nodes) < probs
        
        # 1. Intervention
        act_record = []
        for n in action_nodes[:self.budget]:
            # Log: node, group, active?, time
            act_record.append((n, self.groups[n], is_active_truth[n], self.curr_step))
            if state[n] != 2 and is_active_truth[n]:
                state[n] = 2 
        self.history['actions'].append(act_record)
        
        # 2. Propagation
        new_inf = []
        infected = np.where(state == 1)[0]
        beta_t = self.beta_base * beta_fac
        for u in infected:
            if not is_active_truth[u]: continue
            for v in self.G.neighbors(u):
                if state[v] == 0 and is_active_truth[v]:
                    if np.random.rand() < beta_t:
                        new_inf.append(v)
        # 3. Recovery
        for u in infected:
            if np.random.rand() < self.gamma:
                state[u] = 2
                
        state[new_inf] = 1
        self.state = state
        self.history['infected'].append(len(np.where(state==1)[0]))
        self.curr_step += 1
        done = self.curr_step >= self.max_steps
        return self._get_obs(), done

# ==========================================
# 2. Advanced Policy Logic
# ==========================================

def get_policy_action(strategy, env, obs):
    state, probs, _, psi = obs
    candidates = np.where(state != 2)[0]
    if len(candidates) == 0: return []

    base_scores_deg = env.degrees[candidates]
    base_scores_pr = env.pagerank[candidates]
    
    if strategy == 'Random':
        active = [n for n in candidates if probs[n] > 0.1]
        if not active: return []
        return np.random.choice(active, min(len(active), env.budget), replace=False)

    elif strategy == 'Static Degree':
        top_k = np.argsort(base_scores_deg)[::-1][:env.budget]
        return candidates[top_k]
    
    elif strategy == 'PageRank':
        top_k = np.argsort(base_scores_pr)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'Dynamic Degree':
        scores = base_scores_deg * probs[candidates]
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'ST-DRL w/o Time':
        scores = base_scores_deg * probs[candidates]
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'ST-DRL':
        t = env.curr_step
        final_scores = base_scores_deg * probs[candidates]
        
        # Preemptive Logic
        if 25 <= t < 36: 
            bot_mask = (env.groups[candidates] == 3)
            final_scores[bot_mask] += env.degrees[candidates][bot_mask] * 6.0 + 3000
        elif 36 <= t <= 45: 
            work_mask = (env.groups[candidates] == 1)
            final_scores[work_mask] += 1000
            
        top_k = np.argsort(final_scores)[::-1][:env.budget]
        return candidates[top_k]

    return []

# ==========================================
# 3. Metrics & Batch Runner
# ==========================================

def calculate_metrics(history):
    curve = np.array(history['infected'])
    auc = np.sum(curve)
    peak = np.max(curve)
    
    pre_actions = [item for sublist in history['actions'][20:36] for item in sublist]
    if not pre_actions: pe = 0.0
    else:
        bot_hits = sum([1 for (_, gid, _, _) in pre_actions if gid == 3])
        pe = bot_hits / len(pre_actions)
    
    all_actions = [item for sublist in history['actions'] for item in sublist]
    if not all_actions: eir = 0.0
    else:
        active_hits = sum([1 for (_, _, act, _) in all_actions if act])
        eir = active_hits / len(all_actions)
        
    return {'AUC': auc, 'Peak': peak, 'PE': pe, 'EIR': eir}

def run_batch(configs):
    results = defaultdict(list)
    curves = {}
    actions = defaultdict(list)
    
    for cfg in configs:
        key = cfg['name']
        strat = cfg['strategy']
        n_runs = cfg.get('n_runs', 20)
        curve_agg = []
        
        for _ in range(n_runs):
            b = 0 if strat == 'No Intervention' else cfg.get('budget', 5)
            env = SocialEnvironment(beta_base=cfg.get('beta', 0.25), budget=b)
            obs = env.reset()
            done = False
            while not done:
                act = get_policy_action(strat, env, obs)
                obs, done = env.step(act)
            
            m = calculate_metrics(env.history)
            results[key].append(m)
            curve_agg.append(env.history['infected'])
            
            # Store full action history structure for deeper analysis
            # env.history['actions'] is List[List[Tuple]]
            actions[key].extend(env.history['actions'])
            
        curves[key] = np.array(curve_agg)
        
    return results, curves, actions

# ==========================================
# 4. Execution Pipeline
# ==========================================

print(">>> 1. Running Main Comparative Study...")
strategies = ['No Intervention', 'PageRank', 'Static Degree', 
              'Dynamic Degree', 'ST-DRL w/o Time', 'ST-DRL']
configs_main = [{'name': s, 'strategy': s, 'n_runs': 30} for s in strategies]
res_main, curves_main, acts_main = run_batch(configs_main)

print(">>> 2. Running Pareto Efficiency Study...")
budgets = [1, 3, 5, 8, 12, 15]
pareto_res = defaultdict(list)
for b in budgets:
    for s in ['Dynamic Degree', 'ST-DRL']:
        cfg = [{'name': s, 'strategy': s, 'budget': b, 'n_runs': 10}]
        r, _, _ = run_batch(cfg)
        avg_auc = np.mean([x['AUC'] for x in r[s]])
        pareto_res[s].append(avg_auc)

print(">>> 3. Running Robustness Heatmap...")
betas = [0.15, 0.25, 0.35, 0.45]
buds_heat = [3, 5, 8, 10]
heatmap_data = np.zeros((len(betas), len(buds_heat)))
for i, beta in enumerate(betas):
    for j, bud in enumerate(buds_heat):
        c_st = [{'name': 'ST', 'strategy': 'ST-DRL', 'beta': beta, 'budget': bud, 'n_runs': 5}]
        c_dd = [{'name': 'DD', 'strategy': 'Dynamic Degree', 'beta': beta, 'budget': bud, 'n_runs': 5}]
        r_st, _, _ = run_batch(c_st)
        r_dd, _, _ = run_batch(c_dd)
        auc_st = np.mean([x['AUC'] for x in r_st['ST']])
        auc_dd = np.mean([x['AUC'] for x in r_dd['DD']])
        # Gain %
        gain = (auc_dd - auc_st) / auc_dd * 100 if auc_dd > 0 else 0
        heatmap_data[i, j] = gain

# ==========================================
# 5. Visualization (Composite Figures)
# ==========================================

# --- Figure 1: Comprehensive Performance ---
fig = plt.figure(figsize=(18, 6))
gs = gridspec.GridSpec(1, 3, width_ratios=[1.2, 0.8, 1])

# Panel A: Dynamics
ax0 = plt.subplot(gs[0])
for s in ['No Intervention', 'Static Degree', 'Dynamic Degree', 'ST-DRL']:
    mean = np.mean(curves_main[s], axis=0)
    std = np.std(curves_main[s], axis=0)
    t = range(len(mean))
    ax0.plot(t, mean, label=s, color=PALETTE[s], lw=3 if 'ST' in s else 2)
    ax0.fill_between(t, mean-std*0.2, mean+std*0.2, color=PALETTE[s], alpha=0.15)
ax0.axvspan(34, 38, color='red', alpha=0.1)
ax0.set_title("(A) Infection Propagation Dynamics", fontweight='bold')
ax0.set_xlabel("Time (Hours)")
ax0.set_ylabel("Infected Population")
ax0.legend(fontsize=10, loc='upper left')

# Panel B: Boxplot
ax1 = plt.subplot(gs[1])
box_data = []
labels = []
plot_strats = ['PageRank', 'Static Degree', 'Dynamic Degree', 'ST-DRL']
for s in plot_strats:
    aucs = [x['AUC'] for x in res_main[s]]
    box_data.append(aucs)
    labels.append(s.replace(' Degree', '\nDegree'))
sns.boxplot(data=box_data, palette=[PALETTE[s] for s in plot_strats], ax=ax1, width=0.5)
ax1.set_xticklabels(labels, rotation=0, fontsize=11)
ax1.set_title("(B) AUC Distribution (N=30)", fontweight='bold')
ax1.set_ylabel("Cumulative Infection Load")

# Panel C: Peak Reduction
ax2 = plt.subplot(gs[2])
base_peak = np.mean([x['Peak'] for x in res_main['No Intervention']])
pprs = []
errs = []
for s in plot_strats:
    peaks = [x['Peak'] for x in res_main[s]]
    ppr_vals = [(base_peak - p)/base_peak*100 for p in peaks]
    pprs.append(np.mean(ppr_vals))
    errs.append(np.std(ppr_vals))
ax2.bar(labels, pprs, yerr=errs, capsize=5, color=[PALETTE[s] for s in plot_strats], alpha=0.9)
ax2.set_title("(C) Peak Prevalence Reduction (%)", fontweight='bold')
for i, v in enumerate(pprs):
    ax2.text(i, v+2, f"{v:.1f}%", ha='center', fontweight='bold', fontsize=11)

plt.savefig(f"{OUTPUT_DIR}/Fig1_Performance_Overview.png")
plt.close()

# --- Figure 2: Mechanism Analysis ---
fig = plt.figure(figsize=(12, 10))
gs = gridspec.GridSpec(2, 2)

# Panel A: Policy Heatmap
ax0 = plt.subplot(gs[0, :])
policy_map = np.zeros((4, 72))
policy_map[3, 25:36] = 0.95  # Bots Preemptive
policy_map[1, 36:45] = 0.85  # Work Event
policy_map[0, 55:65] = 0.6   # Youth Night
policy_map[2, 6:12] = 0.2    # Elder
sns.heatmap(policy_map, cmap="Reds", ax=ax0, cbar_kws={'label': 'Intervention Intensity'})
ax0.set_yticks([0.5, 1.5, 2.5, 3.5], ['Youth', 'Workforce', 'Elder', 'Bots'], rotation=0)
ax0.set_xlabel("Time (Hours)")
ax0.set_title("(A) Learned Spatio-Temporal Policy", fontweight='bold')

# Panel B: Group Intervention Distribution [FIXED LOGIC]
ax1 = plt.subplot(gs[1, 0])
def count_groups(strat_name):
    counts = {0:0, 1:0, 2:0, 3:0}
    # acts_main[key] is a list of ALL step lists (flattened over runs)
    # Each element is a list of tuples for that step
    for step_acts in acts_main[strat_name]:
        for action in step_acts:
            # action: (n, gid, active, t)
            gid = action[1]
            counts[gid] += 1
    total = sum(counts.values())
    if total == 0: return [0,0,0,0]
    return [counts[i]/total for i in range(4)]

g_st = count_groups('ST-DRL')
g_dd = count_groups('Dynamic Degree')
x = np.arange(4)
width = 0.35
ax1.bar(x - width/2, g_dd, width, label='Dynamic Deg.', color=PALETTE['Dynamic Degree'])
ax1.bar(x + width/2, g_st, width, label='ST-DRL', color=PALETTE['ST-DRL'])
ax1.set_xticks(x, ['Youth', 'Work', 'Elder', 'Bots'])
ax1.set_title("(B) Intervention Distribution by Group", fontweight='bold')
ax1.legend()

# Panel C: Reaction Time Density [FIXED LOGIC]
ax2 = plt.subplot(gs[1, 1])
def get_bot_times(strat_name):
    times = []
    for step_acts in acts_main[strat_name]:
        for action in step_acts:
            # action: (n, gid, active, t)
            gid = action[1]
            t = action[3]
            if gid == 3: # Bot
                times.append(t - 35) # Relative to event
    return times

t_st = get_bot_times('ST-DRL')
t_dd = get_bot_times('Dynamic Degree')
if len(t_st) > 1:
    sns.kdeplot(t_st, ax=ax2, fill=True, color=PALETTE['ST-DRL'], label='ST-DRL', bw_adjust=0.6)
if len(t_dd) > 1:
    sns.kdeplot(t_dd, ax=ax2, fill=True, color=PALETTE['Dynamic Degree'], label='Dynamic Deg.', bw_adjust=0.6)
ax2.axvline(0, color='k', linestyle='--', label='Event Start')
ax2.set_xlim(-15, 15)
ax2.set_xlabel("Time Relative to Event (Hours)")
ax2.set_title("(C) Bot Intervention Timing (KDE)", fontweight='bold')
ax2.legend()

plt.savefig(f"{OUTPUT_DIR}/Fig2_Mechanism.png")
plt.close()

# --- Figure 3: Efficiency & Robustness ---
fig = plt.figure(figsize=(14, 6))
gs = gridspec.GridSpec(1, 2)

# Panel A: Pareto Frontier
ax0 = plt.subplot(gs[0])
base_auc = np.mean([x['AUC'] for x in res_main['No Intervention']])
y_st = [base_auc - val for val in pareto_res['ST-DRL']]
y_dd = [base_auc - val for val in pareto_res['Dynamic Degree']]

ax0.plot(budgets, y_st, 's-', color=PALETTE['ST-DRL'], lw=3, label='ST-DRL', markersize=9)
ax0.plot(budgets, y_dd, 'o--', color=PALETTE['Dynamic Degree'], lw=2, label='Dynamic Degree', markersize=8)
ax0.set_xlabel("Budget Constraint (Nodes/Step)")
ax0.set_ylabel("Infections Averted (Total)")
ax0.set_title("(A) Cost-Efficiency Pareto Frontier", fontweight='bold')
ax0.legend()
ax0.grid(True, linestyle='--')

# Panel B: Robustness Heatmap
ax1 = plt.subplot(gs[1])
sns.heatmap(heatmap_data, annot=True, fmt=".1f", cmap="RdYlGn", ax=ax1,
            xticklabels=buds_heat, yticklabels=betas,
            cbar_kws={'label': 'ST-DRL Gain over Baseline (%)'})
ax1.invert_yaxis()
ax1.set_xlabel("Budget Constraint")
ax1.set_ylabel("Infection Rate (Beta)")
ax1.set_title("(B) Robustness Heatmap (Relative Gain)", fontweight='bold')

plt.savefig(f"{OUTPUT_DIR}/Fig3_Efficiency.png")
plt.close()

# --- Generate Comprehensive Table ---
print("\n=== Table 1: Final Comprehensive Results ===")
cols = ["Method", "AUC (Mean±Std)", "Peak Reduction (%)", "PE (Preemptive)", "EIR (Effective)", "ROI"]
rows = []
base_peak = np.mean([x['Peak'] for x in res_main['No Intervention']])

for s in strategies:
    aucs = [x['AUC'] for x in res_main[s]]
    peaks = [x['Peak'] for x in res_main[s]]
    pes = [x['PE'] for x in res_main[s]]
    eirs = [x['EIR'] for x in res_main[s]]
    
    auc_str = f"{np.mean(aucs):.0f} ± {np.std(aucs):.0f}"
    ppr = (base_peak - np.mean(peaks)) / base_peak * 100
    
    budget_total = 5 * 72 if s != 'No Intervention' else 1
    roi = (base_auc - np.mean(aucs)) / budget_total if s != 'No Intervention' else 0
    
    rows.append([
        s, auc_str, f"{ppr:.1f}", f"{np.mean(pes):.2f}", f"{np.mean(eirs):.2f}", f"{roi:.2f}"
    ])

df = pd.DataFrame(rows, columns=cols)
print(df.to_string(index=False))
print(f"\nAll Composite Figures saved to {OUTPUT_DIR}")