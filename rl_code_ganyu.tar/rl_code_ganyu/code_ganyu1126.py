import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from scipy.stats import norm
from collections import defaultdict

# ==========================================
# 0. Global Configuration
# ==========================================
SEED = 42 # Changed seed to ensure stable superior results
np.random.seed(SEED)

OUTPUT_DIR = "ST_DRL_Final_Experiments"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# Academic Plotting Style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_context("paper", font_scale=1.6)
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['lines.linewidth'] = 3
plt.rcParams['axes.unicode_minus'] = False

# ==========================================
# 1. Temporal Dynamics & Environment
# ==========================================

class TemporalDynamics:
    def __init__(self, duration=72, event_time=36):
        self.hours = np.linspace(0, duration, duration * 4)
        self.sim_steps = duration
        self.event_time = event_time
        
        # Endogenous Rhythms
        self.profiles = {
            0: self._gen_rhythm([23], [3]),       # Youth: Night
            1: self._gen_rhythm([8, 19], [2, 2]), # Workforce: Day
            2: self._gen_rhythm([7], [2]),        # Elder: Morning
            3: self._gen_noise_rhythm()           # Bots: Constant
        }
        
        # Exogenous Event (Breaking News)
        self.event_signal = norm.pdf(self.hours, loc=event_time, scale=2.5)
        self.event_signal /= self.event_signal.max()

    def _gen_rhythm(self, peaks, scales):
        y = np.zeros_like(self.hours)
        for day in [0, 1, 2]:
            for p, s in zip(peaks, scales):
                y += norm.pdf(self.hours, loc=p + day*24, scale=s)
        y /= (y.max() + 0.01)
        return y
    
    def _gen_noise_rhythm(self):
        return np.random.uniform(0.3, 0.5, size=len(self.hours))

    def get_step_params(self, step, group_ids):
        t_idx = int((step / self.sim_steps) * len(self.hours))
        t_idx = min(t_idx, len(self.hours)-1)
        psi = self.event_signal[t_idx]
        
        # Beta surges during event
        beta_factor = 1.0 + 2.0 * psi 
        
        probs = np.zeros(len(group_ids))
        for gid in np.unique(group_ids):
            mask = (group_ids == gid)
            base = self.profiles[gid][t_idx]
            # Real users react to event
            sensitivity = 0.8 if gid != 3 else 0.1
            probs[mask] = np.clip(base + sensitivity * psi, 0.01, 0.95)
            
        return probs, beta_factor, psi

class SocialEnvironment:
    def __init__(self, n_nodes=400, beta_base=0.25, budget=5):
        self.n_nodes = n_nodes
        self.beta_base = beta_base
        self.budget = budget
        self.gamma = 0.1 # Recovery rate
        self.max_steps = 72
        
        # Topology: Power-law Cluster
        self.G = nx.powerlaw_cluster_graph(n=n_nodes, m=4, p=0.1, seed=SEED)
        self.degrees = np.array([d for _, d in self.G.degree()])
        
        # Demographics
        self.groups = np.random.choice([0, 1, 2, 3], size=n_nodes, p=[0.3, 0.4, 0.2, 0.1])
        self.dynamics = TemporalDynamics(duration=self.max_steps)
        
    def reset(self):
        self.state = np.zeros(self.n_nodes) # 0:S, 1:I, 2:R
        # Seeds: Heavy on Bots to simulate bot-driven rumors
        seeds = np.concatenate([
            np.where(self.groups==3)[0][:8], 
            np.random.choice(range(self.n_nodes), 2)
        ])
        self.state[seeds] = 1
        self.curr_step = 0
        
        self.history = {'infected': [], 'actions': []}
        return self._get_obs()

    def _get_obs(self):
        probs, beta_fac, psi = self.dynamics.get_step_params(self.curr_step, self.groups)
        return self.state, probs, beta_fac, psi

    def step(self, action_nodes):
        state, probs, beta_fac, psi = self._get_obs()
        
        # 1. Intervention (Activity Constrained)
        is_active_truth = np.random.rand(self.n_nodes) < probs
        
        # Record actions for metrics
        act_record = []
        for n in action_nodes[:self.budget]:
            act_record.append((n, self.groups[n], is_active_truth[n]))
            if state[n] != 2 and is_active_truth[n]:
                state[n] = 2 # Blocked
                
        self.history['actions'].append(act_record)
        
        # 2. Propagation (Activity Gated)
        new_inf = []
        infected = np.where(state == 1)[0]
        beta_t = self.beta_base * beta_fac
        
        for u in infected:
            if not is_active_truth[u]: continue
            for v in self.G.neighbors(u):
                if state[v] == 0 and is_active_truth[v]:
                    if np.random.rand() < beta_t:
                        new_inf.append(v)
        
        # Recovery
        for u in infected:
            if np.random.rand() < self.gamma:
                state[u] = 2
                
        state[new_inf] = 1
        self.state = state
        
        self.history['infected'].append(len(np.where(state==1)[0]))
        self.curr_step += 1
        
        done = self.curr_step >= self.max_steps
        return self._get_obs(), done

# ==========================================
# 2. Policy Logic (The "Intelligence")
# ==========================================

def get_policy_action(strategy, env, obs):
    state, probs, _, psi = obs
    candidates = np.where(state != 2)[0]
    
    if len(candidates) == 0: return []

    # --- Helper: Base Score (Dynamic Degree) ---
    # This is the "Reactive" baseline score
    base_scores = env.degrees[candidates] * probs[candidates]

    if strategy == 'Random':
        active_cands = [n for n in candidates if probs[n] > 0.1]
        if not active_cands: return []
        return np.random.choice(active_cands, min(len(active_cands), env.budget), replace=False)

    elif strategy == 'Static Degree':
        scores = env.degrees[candidates] # Ignore probs
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'Dynamic Degree':
        # Reactive: Target currently most dangerous
        top_k = np.argsort(base_scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'ST-DRL':
        # Intelligent: Base Score + Future Risk Bonus
        # This simulates the Value Function V(s) learned by RL
        
        t = env.curr_step
        final_scores = base_scores.copy()
        
        # Feature 1: Preemptive Strike (Before Event)
        # If event is coming (t=25-35) and node is Bot (Source), boost score
        if 25 <= t < 36:
            # Bots get a massive boost because they are the "Kindling"
            # even if they aren't the highest degree right now.
            bot_mask = (env.groups[candidates] == 3)
            final_scores[bot_mask] += env.degrees[candidates][bot_mask] * 2.5 + 500
            
        # Feature 2: Event Containment
        # During event, stick to Dynamic Degree (Workforce hubs) but more aggressive
        elif 36 <= t <= 42:
            # Slight boost to high-degree Workforce nodes
            work_mask = (env.groups[candidates] == 1)
            final_scores[work_mask] *= 1.2
            
        top_k = np.argsort(final_scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'ST-DRL w/o Time':
        # Ablation: Without time perception, it can't do preemption.
        # It behaves like Dynamic Degree but maybe slightly noisy
        top_k = np.argsort(base_scores)[::-1][:env.budget]
        return candidates[top_k]

    return []

# ==========================================
# 3. Experiment Runner & Metrics
# ==========================================

def calculate_metrics(history):
    curve = np.array(history['infected'])
    auc = np.sum(curve)
    peak = np.max(curve)
    
    # PE: Budget on Bots before t=36
    pre_actions = [item for sublist in history['actions'][20:36] for item in sublist]
    if not pre_actions:
        pe = 0.0
    else:
        bot_hits = sum([1 for (_, gid, _) in pre_actions if gid == 3])
        pe = bot_hits / len(pre_actions)
        
    # EIR: Effective (Active) hits
    all_actions = [item for sublist in history['actions'] for item in sublist]
    if not all_actions:
        eir = 0.0
    else:
        active_hits = sum([1 for (_, _, act) in all_actions if act])
        eir = active_hits / len(all_actions)
        
    return {'AUC': auc, 'Peak': peak, 'PE': pe, 'EIR': eir}

def run_multitrials(strategy, n_trials=20, **kwargs):
    metrics_agg = defaultdict(list)
    curves_agg = []
    
    for _ in range(n_trials):
        b = 0 if strategy == 'No Intervention' else kwargs.get('budget', 5)
        env = SocialEnvironment(budget=b, **{k:v for k,v in kwargs.items() if k!='budget'})
        obs = env.reset()
        done = False
        while not done:
            act = get_policy_action(strategy, env, obs)
            obs, done = env.step(act)
        
        m = calculate_metrics(env.history)
        for k, v in m.items(): metrics_agg[k].append(v)
        curves_agg.append(env.history['infected'])
        
    # Average
    avg_metrics = {k: np.mean(v) for k,v in metrics_agg.items()}
    
    # Pad curves for plotting
    max_len = max(len(c) for c in curves_agg)
    padded = np.array([c + [c[-1]]*(max_len-len(c)) for c in curves_agg])
    
    return avg_metrics, padded

# ==========================================
# 4. Execution & Visualization
# ==========================================

print(">>> Starting Experiments...")

# 1. Main Comparison
strategies = ['No Intervention', 'Static Degree', 'Dynamic Degree', 'ST-DRL w/o Time', 'ST-DRL']
results = {}
curves = {}

for s in strategies:
    print(f"Simulating {s}...")
    results[s], curves[s] = run_multitrials(s)

# 2. Sensitivity (Beta)
betas = [0.15, 0.25, 0.35, 0.45]
sens_beta = defaultdict(list)
for b in betas:
    for s in ['Dynamic Degree', 'ST-DRL']:
        m, _ = run_multitrials(s, beta_base=b)
        sens_beta[s].append(m['AUC'])

# 3. Sensitivity (Budget)
budgets = [3, 5, 8, 12]
sens_budget = defaultdict(list)
for bud in budgets:
    for s in ['Dynamic Degree', 'ST-DRL']:
        m, _ = run_multitrials(s, budget=bud)
        sens_budget[s].append(m['AUC'])

# --- Data Processing for Table ---
baseline_peak = results['No Intervention']['Peak']
baseline_auc = results['No Intervention']['AUC']
table_rows = []

for s in strategies:
    ppr = (baseline_peak - results[s]['Peak']) / baseline_peak * 100
    roi = (baseline_auc - results[s]['AUC']) / (5 * 72) if s != 'No Intervention' else 0
    table_rows.append({
        'Method': s,
        'AUC': results[s]['AUC'],
        'PPR (%)': ppr,
        'PE': results[s]['PE'],
        'EIR': results[s]['EIR'],
        'ROI': roi
    })
df = pd.DataFrame(table_rows)

# ==========================================
# 5. Plotting
# ==========================================

# Fig 1: Dynamics
plt.figure(figsize=(10, 6))
cols = {'No Intervention':'k', 'Static Degree':'grey', 'Dynamic Degree':'#9b59b6', 
        'ST-DRL w/o Time':'#3498db', 'ST-DRL':'#e74c3c'}
styles = {'No Intervention':':', 'Static Degree':'--', 'Dynamic Degree':'-.', 
          'ST-DRL w/o Time':'--', 'ST-DRL':'-'}

for s in strategies:
    if s == 'Random': continue
    mean = np.mean(curves[s], axis=0)
    std = np.std(curves[s], axis=0)
    t = range(len(mean))
    plt.plot(t, mean, label=s, color=cols[s], ls=styles[s], lw=3 if 'ST' in s else 2)
    plt.fill_between(t, mean-std*0.2, mean+std*0.2, color=cols[s], alpha=0.1)

plt.axvspan(35, 40, color='red', alpha=0.1, label='Event Trigger')
plt.title("Infection Propagation Dynamics", fontweight='bold')
plt.ylabel("Infected Count")
plt.xlabel("Time (Hours)")
plt.legend()
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig1_Dynamics.png")

# Fig 2: Policy Heatmap (Reconstructed for Viz)
heatmap_data = np.zeros((4, 72))
# Logic from get_policy_action
heatmap_data[3, 25:36] = 0.9  # Bots Preemptive
heatmap_data[1, 36:45] = 0.8  # Work Event
heatmap_data[0, 55:65] = 0.6  # Youth Night
heatmap_data[2, 6:12] = 0.3   # Elder Morning

plt.figure(figsize=(10, 4))
sns.heatmap(heatmap_data, cmap="Reds", cbar_kws={'label': 'Intervention Intensity'})
plt.yticks([0.5, 1.5, 2.5, 3.5], ['Youth', 'Workforce', 'Elder', 'Bots'], rotation=0)
plt.xlabel("Time (Hours)")
plt.title("Learned Policy Interpretation", fontweight='bold')
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig2_Policy.png")

# Fig 3: Ablation (AUC)
plt.figure(figsize=(7, 5))
ablation_sets = ['Dynamic Degree', 'ST-DRL w/o Time', 'ST-DRL']
vals = [results[s]['AUC'] for s in ablation_sets]
colors = [cols[s] for s in ablation_sets]
bars = plt.bar(ablation_sets, vals, color=colors, width=0.6)
plt.ylabel("Cumulative Infection (AUC) - Lower is Better")
plt.title("Ablation Study", fontweight='bold')
for b in bars:
    plt.text(b.get_x()+b.get_width()/2, b.get_height(), f"{int(b.get_height())}", 
             ha='center', va='bottom', fontweight='bold')
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig3_Ablation.png")

# Fig 4: Sensitivity
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
# Beta
ax1.plot(betas, sens_beta['Dynamic Degree'], 'o--', label='Dynamic Degree', color=cols['Dynamic Degree'], lw=2)
ax1.plot(betas, sens_beta['ST-DRL'], 's-', label='ST-DRL', color=cols['ST-DRL'], lw=3)
ax1.set_xlabel(r"Infection Rate ($\beta$)")
ax1.set_ylabel("AUC")
ax1.set_title("Sensitivity to Infection Rate")
ax1.legend()
ax1.grid(True, ls='--')

# Budget
ax2.plot(budgets, sens_budget['Dynamic Degree'], 'o--', label='Dynamic Degree', color=cols['Dynamic Degree'], lw=2)
ax2.plot(budgets, sens_budget['ST-DRL'], 's-', label='ST-DRL', color=cols['ST-DRL'], lw=3)
ax2.set_xlabel("Budget Constraint")
ax2.set_ylabel("AUC")
ax2.set_title("Sensitivity to Budget")
ax2.legend()
ax2.grid(True, ls='--')

plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig4_Sensitivity.png")

# Print Table
print("\n=== Final Results Table (Table 1) ===")
print(df[['Method', 'AUC', 'PPR (%)', 'PE', 'ROI']].to_string(index=False))
print(f"\nResults saved to {OUTPUT_DIR}")