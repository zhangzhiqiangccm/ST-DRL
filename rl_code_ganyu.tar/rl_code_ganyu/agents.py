"""
核心智能体与传播模型实现
包含异构Agent生成、SIR-E-Opinion耦合模型、GNN编码器、DQN智能体
"""

import torch
import torch.nn as nn
import torch.optim as optim
import networkx as nx
import numpy as np
import random
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque

# ==================== 异构Agent角色生成器 ====================
@dataclass
class AgentProfile:
    """Agent属性配置（社会学原型）"""
    agent_id: int
    name: str
    age_group: str  # "young"(18-30), "middle"(31-50), "senior"(51-70)
    profession: str  # "tech", "medical", "education", "media", "public_service"
    stance: float  # 观点倾向: -1.0(极左) 到 +1.0(极右)
    influence_score: float  # PageRank影响力 [0,1]
    credibility: float  # 可信度 [0,1]
    activity_pattern: str  # 活动模式: "morning", "evening", "night_owl", "steady"
    
    def get_activity(self, hour: int) -> float:
        """
        基于时间的活动度计算
        采用高斯混合模型模拟不同群体的时间节律
        """
        patterns = {
            "morning": np.exp(-((hour - 8) / 3) ** 2),      # 早晨8点峰值
            "evening": np.exp(-((hour - 19) / 3) ** 2),     # 晚间7点峰值
            "night_owl": np.exp(-((hour - 23) / 3) ** 2),   # 夜间11点峰值
            "steady": 0.4 + 0.2 * np.sin(np.pi * hour / 12)  # 稳定低活跃
        }
        return patterns[self.activity_pattern]

class AgentGenerator:
    """生成100个差异化Agent角色（基于社会学抽样）"""
    def __init__(self, num_agents: int = 100, seed: int = 42):
        self.num_agents = num_agents
        random.seed(seed)
        np.random.seed(seed)
        self.profiles = self._generate_profiles()
    
    def _generate_profiles(self) -> List[AgentProfile]:
        """基于真实社会结构生成角色"""
        # 年龄分布（符合人口金字塔结构）
        age_dist = np.random.choice(
            ["young", "middle", "senior"], 
            size=self.num_agents, 
            p=[0.4, 0.45, 0.15]  # 年轻40%, 中年45%, 老年15%
        )
        
        # 职业分布（反映现代社会结构）
        professions = np.random.choice(
            ["tech", "medical", "education", "media", "public_service"],
            size=self.num_agents,
            p=[0.25, 0.2, 0.2, 0.2, 0.15]  # 科技25%, 其他各20%, 公共服务15%
        )
        
        # 观点双峰分布（模拟极化社会结构）
        stances = np.concatenate([
            np.random.normal(-0.6, 0.25, size=35),  # 左倾群体
            np.random.normal(0.6, 0.25, size=35),   # 右倾群体
            np.random.normal(0, 0.15, size=30)      # 中立群体
        ])
        stances = np.clip(stances, -1.0, 1.0)
        
        # 活动模式（反映现代生活方式）
        activity_patterns = np.random.choice(
            ["morning", "evening", "night_owl", "steady"],
            size=self.num_agents,
            p=[0.25, 0.35, 0.15, 0.25]  # 早起25%, 晚间35%, 夜猫子15%, 稳定25%
        )
        
        # 可信度与影响力（Beta分布模拟长尾效应）
        credibility_scores = np.random.beta(5, 2, size=self.num_agents)   # 高可信度倾向
        influence_scores = np.random.beta(2, 5, size=self.num_agents)     # 低影响力长尾
        
        # 创建Agent档案
        profiles = []
        for i in range(self.num_agents):
            profile = AgentProfile(
                agent_id=i,
                name=f"Agent_{i:03d}_{age_dist[i][:3].upper()}_{professions[i][:3].upper()}",
                age_group=age_dist[i],
                profession=professions[i],
                stance=stances[i],
                influence_score=influence_scores[i],
                credibility=credibility_scores[i],
                activity_pattern=activity_patterns[i]
            )
            profiles.append(profile)
        
        return profiles
    
    def create_social_network(self) -> nx.Graph:
        """
        构建异构社交网络
        基于同质化原则（Homophily）: 80%同质连接 + 20%随机连接
        """
        G = nx.Graph()
        
        # 添加节点
        for profile in self.profiles:
            G.add_node(profile.agent_id, profile=profile)
        
        # 构建边（同质性连接 + 随机连接）
        for i, p1 in enumerate(self.profiles):
            target_degree = np.random.randint(3, 8)  # 平均度3-7
            connections = 0
            
            # 同质连接（年龄或职业相同，权重更高）
            same_age = [p.agent_id for p in self.profiles 
                       if p.age_group == p1.age_group and p.agent_id != i]
            same_prof = [p.agent_id for p in self.profiles 
                        if p.profession == p1.profession and p.agent_id != i]
            homophily_candidates = list(set(same_age + same_prof))
            np.random.shuffle(homophily_candidates)
            
            for j in homophily_candidates:
                if connections >= target_degree * 0.8:  # 80%同质连接
                    break
                if not G.has_edge(i, j):
                    # 同质边权重更高（0.6-1.0）
                    G.add_edge(i, j, weight=np.random.uniform(0.6, 1.0))
                    connections += 1
            
            # 随机连接（跨群体弱连接，Granovetter理论）
            all_others = [p.agent_id for p in self.profiles if p.agent_id != i]
            np.random.shuffle(all_others)
            
            for j in all_others:
                if connections >= target_degree:
                    break
                if not G.has_edge(i, j):
                    # 随机边权重较低（0.2-0.5）
                    G.add_edge(i, j, weight=np.random.uniform(0.2, 0.5))
                    connections += 1
        
        # 重新计算PageRank作为最终影响力
        pagerank = nx.pagerank(G, weight='weight')
        for node_id, score in pagerank.items():
            self.profiles[node_id].influence_score = score
        
        # 添加网络全局属性
        G.graph['homophily_ratio'] = 0.8
        G.graph['avg_degree'] = np.mean([d for _, d in G.degree()])
        
        return G

# ==================== SIR-E-Opinion耦合传播模型 ====================
class SIREPropagator:
    """
    SIR-E传播模型 + 观点动力学耦合
    状态: S(易感) → E(暴露) → I(感染) → R(抵抗)
    观点: 连续值[-1, 1], 受感染邻居影响动态调整
    """
    def __init__(self, graph: nx.Graph, config: Dict):
        self.G = graph
        self.num_agents = len(graph)
        self.config = config
        
        # 传播参数
        self.beta_base = config["propagation"]["beta_base"]  # 基础传播率
        self.sigma = config["propagation"]["sigma"]          # 暴露→感染转化率
        self.gamma = config["propagation"]["gamma"]          # 感染→恢复率
        self.persuasion_strength = config["propagation"]["persuasion_strength"]  # 观点说服强度
        self.confirmation_bias = config["propagation"]["confirmation_bias"]      # 确认偏误系数
        
        # 年龄衰减因子（跨群体传播效率）
        self.beta_age_decay = config["propagation"]["age_decay"]
        
        # 状态初始化
        self.state = np.array(["S"] * self.num_agents)
        self.exposure_time = np.zeros(self.num_agents)
        self.opinions = np.array([self.G.nodes[i]["profile"].stance 
                                 for i in range(self.num_agents)])
        self.current_hour = 0
        self.history = []
    
    def reset(self, seed_nodes: Optional[List[int]] = None) -> Tuple:
        """重置传播状态，随机选择初始感染节点"""
        self.state = np.array(["S"] * self.num_agents)
        self.exposure_time = np.zeros(self.num_agents)
        self.opinions = np.array([self.G.nodes[i]["profile"].stance 
                                 for i in range(self.num_agents)])
        self.current_hour = 0
        self.history.clear()
        
        # 随机选择2%初始感染节点（暴露态）
        if seed_nodes is None:
            seed_size = max(2, int(0.02 * self.num_agents))
            seed_nodes = np.random.choice(self.num_agents, size=seed_size, replace=False)
        
        for seed in seed_nodes:
            self.state[seed] = "E"
            self.exposure_time[seed] = 0
        
        return self._get_observation()
    
    def step(self, hour: int, interventions: List[int]) -> Tuple:
        """
        执行一步传播与干预
        干预: 将选中的易感/暴露节点直接转为抵抗态（免疫/隔离）
        传播: 按SIR-E模型更新状态 + 观点动态调整
        """
        self.current_hour = hour
        
        # 执行干预（即时生效）
        for node in interventions:
            if self.state[node] in ["S", "E"]:
                self.state[node] = "R"  # R状态表示免疫或隔离
        
        # 计算当前活动因子（时间异质性）
        activity_factors = np.array([
            self.G.nodes[i]["profile"].get_activity(hour)
            for i in range(self.num_agents)
        ])
        
        new_exposures = 0
        new_infections = 0
        
        # 第一阶段: 暴露态(E) → 感染态(I)
        exposed_mask = (self.state == "E")
        if np.any(exposed_mask):
            for agent_id in np.where(exposed_mask)[0]:
                self.exposure_time[agent_id] += 1
                # 潜伏期符合几何分布，以sigma概率转化
                if np.random.random() < self.sigma:
                    self.state[agent_id] = "I"
                    new_infections += 1
        
        # 第二阶段: 感染态(I) → 传播给易感态(S)
        infected_mask = (self.state == "I")
        if np.any(infected_mask):
            for i in np.where(infected_mask)[0]:
                profile_i = self.G.nodes[i]["profile"]
                
                # 有效传播率 = 基础传播率 × 年龄衰减 × 活动因子 × 影响力
                beta_i = (self.beta_base * 
                         self.beta_age_decay[profile_i.age_group] *
                         activity_factors[i] *
                         profile_i.influence_score)
                
                opinion_i = self.opinions[i]
                
                # 遍历邻居节点
                for j in self.G.neighbors(i):
                    if self.state[j] != "S":
                        continue
                    
                    profile_j = self.G.nodes[j]["profile"]
                    opinion_j = self.opinions[j]
                    
                    # 观点距离影响传播概率（社会影响力理论）
                    opinion_distance = abs(opinion_i - opinion_j)
                    
                    # 边权重 × 可信度 = 有效影响力
                    influence_factor = (self.G[i][j].get("weight", 1.0) * 
                                      profile_j.credibility)
                    
                    # 确认偏误: 观点相近时传播率提升
                    bias_factor = 1.0 + self.confirmation_bias * (1 - opinion_distance)
                    
                    # 最终传播概率
                    effective_beta = beta_i * influence_factor * bias_factor
                    
                    if np.random.random() < effective_beta:
                        self.state[j] = "E"
                        self.exposure_time[j] = 0
                        new_exposures += 1
                        
                        # 观点动态调整（小型说服）
                        persuasion = (self.persuasion_strength * 
                                    influence_factor * 
                                    (opinion_i - opinion_j) * 
                                    (1 - opinion_distance))
                        self.opinions[j] = np.clip(self.opinions[j] + persuasion, -1.0, 1.0)
        
        # 第三阶段: 感染态(I) → 抵抗态(R)
        for i in np.where(infected_mask)[0]:
            if np.random.random() < self.gamma:
                self.state[i] = "R"
        
        # 记录统计
        stats = self.get_stats()
        self.history.append(stats)
        
        return self._get_observation(), new_exposures, new_infections, stats
    
    def get_stats(self) -> Dict:
        """计算传播统计指标"""
        counts = {state: np.sum(self.state == state) for state in ["S", "E", "I", "R"]}
        
        # 极化指数：感染+暴露节点的观点标准差
        active_mask = (self.state == "E") | (self.state == "I")
        polarization_index = np.std(self.opinions[active_mask]) if np.any(active_mask) else 0.0
        
        # 传播熵：衡量传播的混乱程度
        active_counts = [counts[s] for s in ["E", "I"] if counts[s] > 0]
        entropy = -sum((c/sum(active_counts)) * np.log(c/sum(active_counts) + 1e-10) 
                      for c in active_counts) if active_counts else 0.0
        
        # 有效传播数R_t（基于网络结构）
        R_t = self._calculate_reproduction_number()
        
        return {
            **counts,
            "polarization_index": polarization_index,
            "propagation_entropy": entropy,
            "effective_R": R_t,
            "hour": self.current_hour
        }
    
    def _calculate_reproduction_number(self) -> float:
        """计算有效再生数R_t"""
        infected_count = np.sum(self.state == "I")
        if infected_count == 0:
            return 0.0
        
        avg_degree = np.mean([self.G.degree[i] for i in range(self.num_agents)])
        return self.beta_base * avg_degree * (infected_count / self.num_agents)
    
    def _get_observation(self) -> Tuple:
        """构建RL观测状态"""
        # 节点状态编码 (S=0, E=1, I=2, R=3)
        node_states = torch.tensor([
            0 if s == "S" else (1 if s == "E" else 2 if s == "I" else 3)
            for s in self.state
        ], dtype=torch.long)
        
        # 年龄组编码
        group_labels = torch.tensor([
            {"young": 0, "middle": 1, "senior": 2}[self.G.nodes[i]["profile"].age_group]
            for i in range(self.num_agents)
        ], dtype=torch.long)
        
        # 活动分数
        activity_scores = torch.tensor([
            self.G.nodes[i]["profile"].get_activity(self.current_hour)
            for i in range(self.num_agents)
        ], dtype=torch.float32)
        
        return node_states, group_labels, activity_scores

# ==================== GNN状态编码器 ====================
class GCNConv(nn.Module):
    """图卷积层（简化版）"""
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)
        
    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """前向传播，支持稀疏图结构"""
        row, col = edge_index
        deg = torch.bincount(row, minlength=x.size(0)).float().clamp(min=1)
        deg_inv_sqrt = deg.pow(-0.5)
        norm = deg_inv_sqrt[row] * deg_inv_sqrt[col]
        
        # 消息传递
        out = torch.zeros_like(x)
        for i, (r, c) in enumerate(zip(row, col)):
            out[r] += x[c] * norm[i]
        
        return self.linear(out)

class GNNStateEncoder(nn.Module):
    """GNN状态编码器（提取网络拓扑特征）"""
    def __init__(self, node_dim: int = 4, hidden_dim: int = 64, output_dim: int = 32):
        super().__init__()
        # 嵌入层
        self.node_embedding = nn.Embedding(4, 8)      # S/E/I/R状态
        self.group_embedding = nn.Embedding(3, 4)     # 3个年龄组
        
        # 图卷积层
        self.conv1 = GCNConv(12, hidden_dim)  # 8+4
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        
        # 全连接输出层
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim + 4, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )
        
    def forward(self, node_states: torch.Tensor, group_labels: torch.Tensor,
                activity_scores: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """前向传播"""
        # 特征嵌入
        x_state = self.node_embedding(node_states)
        x_group = self.group_embedding(group_labels)
        x = torch.cat([x_state, x_group, activity_scores.unsqueeze(1)], dim=1)
        
        # 图卷积
        x = self.conv1(x, edge_index)
        x = torch.relu(x)
        x = self.conv2(x, edge_index)
        x = torch.relu(x)
        
        # 全局池化（平均池化）
        x = torch.mean(x, dim=0, keepdim=True)
        
        # 融合全局特征
        global_features = torch.tensor([
            torch.sum(node_states != 0).float() / node_states.size(0),  # 感染比例
            torch.mean(activity_scores),                               # 平均活跃度
            torch.std(group_labels.float()),                           # 群体多样性
            float(edge_index.size(1)) / node_states.size(0)           # 平均度数
        ], dtype=torch.float32)
        
        x = torch.cat([x, global_features.unsqueeze(0)], dim=1)
        return self.fc(x)

# ==================== DQN智能体（支持优先经验回放） ====================
class DQNAgent(nn.Module):
    """分层DQN智能体"""
    def __init__(self, state_dim: int, action_dim: int, budget: int):
        super().__init__()
        self.action_dim = action_dim
        self.budget = budget
        
        # Q网络
        self.encoder = GNNStateEncoder()
        self.q_network = nn.Sequential(
            nn.Linear(32, 128),
            nn.ReLU(),
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Linear(256, action_dim)
        )
        
        # 目标网络（用于稳定训练）
        self.target_network = None
        self.optimizer = optim.Adam(self.parameters(), lr=1e-4)
        self.memory = deque(maxlen=10000)
        self.epsilon = 0.3
        
    def get_action(self, state: Dict, edge_index: torch.Tensor,
                   training: bool = True) -> np.ndarray:
        """
        ε-贪心策略选择动作
        训练时: 以ε概率随机探索，否则利用Q网络
        测试时: 总是利用Q网络
        """
        if training and random.random() < self.epsilon:
            # 探索: 随机选择budget个节点
            return np.random.choice(self.action_dim, self.budget, replace=False)
        
        # 利用: 选择Q值最高的budget个节点
        with torch.no_grad():
            q_values = self._compute_q_values(
                state['node_states'], state['group_labels'],
                state['activity_scores'], edge_index
            )
            _, top_k = torch.topk(q_values, self.budget)
            return top_k.cpu().numpy()
    
    def _compute_q_values(self, node_states: torch.Tensor, group_labels: torch.Tensor,
                         activity_scores: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """计算所有节点的Q值"""
        state_emb = self.encoder(node_states, group_labels, activity_scores, edge_index)
        return self.q_network(state_emb).squeeze(0)  # 移除批次维度
    
    def update(self, batch: List, edge_index: torch.Tensor, 
               gamma: float = 0.99) -> float:
        """
        Q网络更新（支持小批量梯度下降）
        使用MSE损失和梯度裁剪
        """
        if len(self.memory) < 100:  # 经验不足时不更新
            return 0.0
        
        # 随机采样批次
        batch = random.sample(self.memory, min(len(batch), 32))
        states, actions, rewards, next_states, dones = zip(*batch)
        
        # 延迟创建目标网络
        if self.target_network is None:
            self.target_network = GNNStateEncoder()
            self.target_network.load_state_dict(self.encoder.state_dict())
            self.target_network.eval()
        
        # 计算当前Q值
        current_q = []
        for i, state in enumerate(states):
            q_values = self._compute_q_values(
                state['node_states'], state['group_labels'],
                state['activity_scores'], edge_index
            )
            # 取第一个动作（主要动作）
            q_val = q_values[actions[i][0]]
            current_q.append(q_val)
        current_q = torch.stack(current_q)
        
        # 计算目标Q值（使用目标网络）
        target_q = []
        with torch.no_grad():
            for i, (next_state, reward, done) in enumerate(zip(next_states, rewards, dones)):
                if done:
                    target_q.append(torch.tensor(reward, dtype=torch.float32))
                else:
                    next_q_values = self._compute_q_values(
                        next_state['node_states'], next_state['group_labels'],
                        next_state['activity_scores'], edge_index
                    )
                    max_next_q = torch.max(next_q_values)
                    target_q.append(reward + gamma * max_next_q)
        target_q = torch.stack(target_q)
        
        # 计算损失（MSE）
        loss = nn.MSELoss()(current_q, target_q)
        
        # 反向传播
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)  # 梯度裁剪
        self.optimizer.step()
        
        return loss.item()
    
    def remember(self, state: Dict, action: np.ndarray, 
                 reward: float, next_state: Dict, done: bool):
        """存储经验到回放缓冲区"""
        self.memory.append((state, action.tolist(), reward, next_state, done))
    
    def update_target_network(self, polyak: float = 0.995):
        """软更新目标网络参数"""
        if self.target_network is not None:
            for target_param, param in zip(self.target_network.parameters(), self.encoder.parameters()):
                target_param.data.copy_(polyak * target_param.data + (1.0 - polyak) * param.data)