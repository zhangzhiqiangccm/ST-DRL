"""
实验框架模块
包含对比实验、消融实验、参数敏感性分析、鲁棒性测试
"""

import numpy as np
import pandas as pd
import networkx as nx
import torch
from typing import Dict, List, Tuple
from scipy.stats import wilcoxon, sem, t
import matplotlib.pyplot as plt
import seaborn as sns

class BaselineAgent:
    """基线策略实现"""
    
    def __init__(self, graph: nx.Graph, budget: int, strategy: str):
        self.G = graph
        self.budget = budget
        self.strategy = strategy
        
        # 预计算中心性指标
        if strategy == "degree":
            self.centrality = dict(graph.degree())
        elif strategy == "eigenvector":
            self.centrality = nx.eigenvector_centrality(graph, weight="weight", max_iter=1000)
        elif strategy == "betweenness":
            self.centrality = nx.betweenness_centrality(graph, weight="weight")
        elif strategy == "pagerank":
            self.centrality = nx.pagerank(graph, weight="weight")
    
    def get_action(self, state: np.ndarray) -> List[int]:
        """根据策略选择动作"""
        if self.strategy == "random":
            return list(np.random.choice(len(self.G), self.budget, replace=False))
        
        elif self.strategy in ["degree", "eigenvector", "betweenness", "pagerank"]:
            # 选择中心性最高的节点
            sorted_nodes = sorted(self.centrality.keys(), 
                                key=lambda x: self.centrality[x], 
                                reverse=True)
            # 只选择当前未被感染的节点
            valid_nodes = [n for n in sorted_nodes if state[n] not in ["I", "R"]]
            return valid_nodes[:self.budget]
        
        elif self.strategy == "greedy":
            # 贪心策略：选择最能减少即时感染的节点
            best_reduction = 0
            best_nodes = []
            
            for node in range(len(self.G)):
                if state[node] in ["I", "R"]:
                    continue
                
                # 模拟干预效果：计算该节点感染邻居的数量
                infected_neighbors = sum(1 for neighbor in self.G.neighbors(node) 
                                       if state[neighbor] == "I")
                
                if infected_neighbors > best_reduction:
                    best_reduction = infected_neighbors
                    best_nodes = [node]
                elif infected_neighbors == best_reduction and len(best_nodes) < self.budget:
                    best_nodes.append(node)
            
            # 如果不足budget，随机填充
            while len(best_nodes) < self.budget:
                candidates = [i for i in range(len(self.G)) if state[i] not in ["I", "R"] and i not in best_nodes]
                if not candidates:
                    break
                best_nodes.append(np.random.choice(candidates))
            
            return best_nodes[:self.budget]
        
        else:
            raise ValueError(f"Unknown baseline strategy: {self.strategy}")

class AblationExperiment:
    """消融实验框架"""
    
    def __init__(self, config: Dict, graph: nx.Graph):
        self.config = config
        self.graph = graph
        self.edge_index = torch.tensor(list(graph.edges()), dtype=torch.long).t()
        
        # 定义消融组件
        self.ablation_components = {
            "full": "完整模型",
            "no_gnn": "移除GNN编码器",  # 用MLP替代
            "no_temporal": "移除时间异质性",  # 活动因子=1
            "no_opinion": "移除观点动力学",  # 关闭观点更新
            "no_reward_shaping": "移除奖励塑形",  # 使用稀疏奖励
            "no_hierarchy": "移除分层策略",  # 单层DQN
        }
    
    def run_ablation(self, episodes: int = 50) -> Dict[str, pd.DataFrame]:
        """运行所有消融实验"""
        results = {}
        
        for component, description in self.ablation_components.items():
            print(f"🔧 运行消融实验: {description}")
            metrics = self._run_single_ablation(component, episodes)
            results[component] = pd.DataFrame(metrics)
        
        # 合并结果
        ablation_summary = self._summarize_ablation_results(results)
        
        # 保存结果
        output_dir = self.config["experiment"]["output_dir"]
        ablation_summary.to_csv(os.path.join(output_dir, "ablation_results.csv"))
        
        # 可视化
        self._plot_ablation_results(ablation_summary, output_dir)
        
        return results
    
    def _run_single_ablation(self, component: str, episodes: int) -> Dict:
        """运行单个消融实验"""
        # 修改配置
        ablation_config = self.config.copy()
        
        if component == "no_gnn":
            ablation_config["rl"]["use_gnn"] = False
        elif component == "no_temporal":
            ablation_config["propagation"]["age_decay"] = {"young": 1.0, "middle": 1.0, "senior": 1.0}
        elif component == "no_opinion":
            ablation_config["propagation"]["persuasion_strength"] = 0.0
        elif component == "no_reward_shaping":
            ablation_config["rl"]["use_shaping"] = False
        elif component == "no_hierarchy":
            ablation_config["rl"]["use_hierarchy"] = False
        
        # 运行实验
        from agents import DQNAgent, SIREPropagator
        from utils import PerformanceTracker
        
        propagator = SIREPropagator(self.graph, ablation_config)
        agent = DQNAgent(state_dim=32, action_dim=len(self.graph), budget=ablation_config["rl"]["budget"])
        tracker = PerformanceTracker()
        
        for episode in range(episodes):
            # 简化训练循环（完整版需集成到主流程）
            stats = propagator.get_stats()
            reward = -stats["I"] - 0.5 * ablation_config["rl"]["budget"]
            tracker.add_episode({
                "episode": episode,
                "final_R": stats["R"],
                "total_reward": reward,
                "interventions": ablation_config["rl"]["budget"]
            })
        
        return tracker.metrics
    
    def _summarize_ablation_results(self, results: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """汇总消融实验结果"""
        summary_data = []
        
        for component, df in results.items():
            if df.empty:
                continue
            
            summary_data.append({
                "Component": self.ablation_components[component],
                "Final_R_Mean": df["final_R"].mean(),
                "Final_R_Std": df["final_R"].std(),
                "Reward_Mean": df["total_reward"].mean(),
                "Reward_Std": df["total_reward"].std(),
                "Degradation": (results["full"]["final_R"].mean() - df["final_R"].mean()) / 
                              results["full"]["final_R"].mean() * 100
            })
        
        return pd.DataFrame(summary_data).sort_values("Degradation", ascending=False)
    
    def _plot_ablation_results(self, summary: pd.DataFrame, output_dir: str):
        """可视化消融实验"""
        fig, ax = plt.subplots(figsize=(12, 6))
        
        components = summary["Component"].values
        degradation = summary["Degradation"].values
        
        bars = ax.barh(components, degradation, color='#d62728', alpha=0.7)
        ax.set_xlabel('Performance Degradation (%)', fontsize=12)
        ax.set_title('Ablation Study: Component Importance', fontsize=14, fontweight='bold')
        
        # 添加数值标签
        for bar, val in zip(bars, degradation):
            ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2,
                   f'{val:.1f}%', ha='left', va='center')
        
        ax.grid(axis='x', alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "ablation_study.png"), 
                    dpi=300, bbox_inches="tight")
        plt.close()

class SensitivityAnalyzer:
    """参数敏感性分析器"""
    
    def __init__(self, config: Dict, graph: nx.Graph):
        self.config = config
        self.graph = graph
        
        # 定义待分析参数
        self.param_grid = {
            "budget": [3, 5, 8, 10],
            "lr": [1e-5, 5e-5, 1e-4, 5e-4],
            "gamma": [0.95, 0.97, 0.99, 0.995],
            "beta_base": [0.15, 0.20, 0.25, 0.30],
            "persuasion_strength": [0.1, 0.15, 0.2, 0.25]
        }
    
    def run_sensitivity_analysis(self, param_name: str, values: List, 
                                episodes: int = 20) -> pd.DataFrame:
        """对单个参数进行敏感性分析"""
        results = []
        
        for value in values:
            print(f"📊 敏感性测试 {param_name} = {value}")
            
            # 修改配置
            sens_config = self.config.copy()
            
            if param_name == "budget":
                sens_config["rl"]["budget"] = value
            elif param_name == "lr":
                sens_config["rl"]["lr"] = value
            elif param_name == "gamma":
                sens_config["rl"]["gamma"] = value
            elif param_name == "beta_base":
                sens_config["propagation"]["beta_base"] = value
            elif param_name == "persuasion_strength":
                sens_config["propagation"]["persuasion_strength"] = value
            
            # 运行简化实验
            from agents import SIREPropagator, DQNAgent
            from utils import PerformanceTracker
            
            propagator = SIREPropagator(self.graph, sens_config)
            agent = DQNAgent(state_dim=32, action_dim=len(self.graph), 
                            budget=sens_config["rl"]["budget"])
            tracker = PerformanceTracker()
            
            # 运行多轮实验取平均
            for episode in range(episodes):
                propagator.reset()
                for step in range(10):  # 简化传播步数
                    hour = (step * 6) % 24
                    action = agent.get_action(
                        {"node_states": torch.zeros(len(self.graph)),
                         "group_labels": torch.zeros(len(self.graph)),
                         "activity_scores": torch.ones(len(self.graph))},
                        torch.tensor(list(self.graph.edges()), dtype=torch.long).t(),
                        training=False
                    )
                    obs, _, _, stats = propagator.step(hour, action)
                tracker.add_episode({
                    "episode": episode,
                    "final_R": stats["R"],
                    "total_reward": -stats["I"] - 0.5 * len(action),
                    "interventions": len(action)
                })
            
            # 计算平均值
            results.append({
                "Parameter": param_name,
                "Value": value,
                "Final_R": tracker.metrics["final_R"][-episodes:].mean(),
                "Reward": tracker.metrics["total_reward"][-episodes:].mean(),
                "Std_Final_R": tracker.metrics["final_R"][-episodes:].std()
            })
        
        return pd.DataFrame(results)
    
    def plot_sensitivity_heatmap(self, results: Dict[str, pd.DataFrame], 
                                output_dir: str):
        """绘制敏感性热力图"""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle('Parameter Sensitivity Analysis', fontsize=16, fontweight='bold')
        
        param_names = list(results.keys())
        
        for idx, (param, df) in enumerate(results.items()):
            if idx >= 4:  # 只显示前4个参数
                break
            
            ax = axes[idx // 2, idx % 2]
            
            # 绘制性能随参数变化
            ax.errorbar(df["Value"], df["Final_R"], yerr=df["Std_Final_R"], 
                       marker='o', capsize=5, linewidth=2, markersize=6)
            ax.set_xlabel(param, fontsize=12)
            ax.set_ylabel('Final Resistant Count', fontsize=12)
            ax.set_title(f'Sensitivity to {param}', fontsize=14)
            ax.grid(True, alpha=0.3)
            
            # 标记最优值
            optimal_idx = df["Final_R"].idxmax()
            optimal_x = df.loc[optimal_idx, "Value"]
            optimal_y = df.loc[optimal_idx, "Final_R"]
            ax.axvline(optimal_x, color='r', linestyle='--', alpha=0.5)
            ax.plot(optimal_x, optimal_y, 'ro', markersize=10, label='Optimal')
            ax.legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "sensitivity_analysis.png"), 
                    dpi=300, bbox_inches="tight")
        plt.close()

class RobustnessTester:
    """鲁棒性测试框架"""
    
    def __init__(self, config: Dict, graph: nx.Graph):
        self.config = config
        self.graph = graph
        
    def run_adversarial_attack(self, attack_ratio: float = 0.1) -> Dict:
        """
        对抗攻击测试：注入恶意Bot节点
        
        攻击特点:
        - 传播率β提升50%
        - 可信度降低至0.1
        - 观点极化（统一设置为极值±0.9）
        """
        from agents import AgentProfile
        
        num_attackers = int(len(self.graph) * attack_ratio)
        attack_nodes = np.random.choice(len(self.graph), num_attackers, replace=False)
        
        # 创建攻击节点档案
        for node_id in attack_nodes:
            # 保留原有连接，修改属性
            self.graph.nodes[node_id]["profile"] = AgentProfile(
                agent_id=node_id,
                name=f"Bot_{node_id:03d}",
                age_group="young",
                profession="media",
                stance=np.random.choice([-0.9, 0.9]),  # 极化观点
                influence_score=0.5,  # 中等影响力
                credibility=0.1,      # 极低可信度
                activity_pattern="steady"
            )
        
        # 运行实验
        from agents import SIREPropagator, DQNAgent
        from utils import PerformanceTracker
        
        propagator = SIREPropagator(self.graph, self.config)
        agent = DQNAgent(state_dim=32, action_dim=len(self.graph), 
                        budget=self.config["rl"]["budget"])
        tracker = PerformanceTracker()
        
        # 运行单轮实验
        propagator.reset(seed_nodes=list(attack_nodes))
        for step in range(self.config["rl"]["max_steps"]):
            hour = (step * 6) % 24
            action = agent.get_action(
                {"node_states": torch.zeros(len(self.graph)),
                 "group_labels": torch.zeros(len(self.graph)),
                 "activity_scores": torch.ones(len(self.graph))},
                torch.tensor(list(self.graph.edges()), dtype=torch.long).t(),
                training=False
            )
            obs, _, _, stats = propagator.step(hour, action)
            
            if stats["I"] == 0:
                break
        
        return {
            "attack_ratio": attack_ratio,
            "final_R": stats["R"],
            "peak_I": max([h["I"] for h in propagator.history]),
            "resilience": stats["R"] / len(self.graph)  # 系统韧性指标
        }
    
    def run_distribution_shift(self, shift_type: str = "uniform") -> Dict:
        """分布偏移测试：改变观点分布"""
        # 修改节点观点分布
        for node_id in range(len(self.graph)):
            if shift_type == "uniform":
                # 均匀分布
                self.graph.nodes[node_id]["profile"].stance = np.random.uniform(-1, 1)
            elif shift_type == "neutral":
                # 所有节点变为中立
                self.graph.nodes[node_id]["profile"].stance = np.random.normal(0, 0.1)
        
        # 运行实验并比较性能差异
        from agents import SIREPropagator, DQNAgent
        
        propagator = SIREPropagator(self.graph, self.config)
        agent = DQNAgent(state_dim=32, action_dim=len(self.graph), 
                        budget=self.config["rl"]["budget"])
        
        # 加载训练好的模型（需要传入）
        # agent.load_state_dict(torch.load(os.path.join(self.config["experiment"]["output_dir"], "model.pth")))
        
        # 运行测试
        propagator.reset()
        total_reward = 0
        for step in range(self.config["rl"]["max_steps"]):
            hour = (step * 6) % 24
            action = agent.get_action(
                {"node_states": torch.zeros(len(self.graph)),
                 "group_labels": torch.zeros(len(self.graph)),
                 "activity_scores": torch.ones(len(self.graph))},
                torch.tensor(list(self.graph.edges()), dtype=torch.long).t(),
                training=False
            )
            obs, _, _, stats = propagator.step(hour, action)
            total_reward += -stats["I"] - 0.5 * len(action)
        
        return {
            "shift_type": shift_type,
            "final_R": stats["R"],
            "total_reward": total_reward,
            "performance_drop": 0  # 与原始分布对比
        }

class StatisticalAnalyzer:
    """统计分析器"""
    
    @staticmethod
    def perform_wilcoxon_test(method1_results: List[float], 
                             method2_results: List[float],
                             alpha: float = 0.05) -> Dict:
        """Wilcoxon符号秩检验"""
        if len(method1_results) != len(method2_results):
            raise ValueError("结果列表长度必须相同")
        
        statistic, p_value = wilcoxon(method1_results, method2_results)
        
        # 计算效应量（r）
        n = len(method1_results)
        effect_size = abs(statistic) / (n * (n + 1) / 2)
        
        return {
            "statistic": statistic,
            "p_value": p_value,
            "significant": p_value < alpha,
            "effect_size": effect_size,
            "interpretation": "large" if effect_size > 0.5 else "medium" if effect_size > 0.3 else "small"
        }
    
    @staticmethod
    def compute_confidence_interval(data: List[float], confidence: float = 0.95) -> Tuple:
        """计算置信区间"""
        n = len(data)
        mean = np.mean(data)
        std_err = sem(data)
        h = std_err * t.paren((1 + confidence) / 2., n-1)
        
        return (mean - h, mean + h)
    
    @staticmethod
    def generate_performance_table(results: Dict[str, Dict], 
                                 confidence_level: float = 0.95) -> pd.DataFrame:
        """
        生成带置信区间的性能表格
        
        输入: {method_name: {"final_R": [list], "reward": [list]}}
        输出: LaTeX格式的DataFrame
        """
        table_data = []
        
        for method, metrics in results.items():
            for metric_name, values in metrics.items():
                if isinstance(values, list):
                    mean = np.mean(values)
                    std = np.std(values)
                    ci_low, ci_high = StatisticalAnalyzer.compute_confidence_interval(values, confidence_level)
                    
                    table_data.append({
                        "Method": method,
                        "Metric": metric_name,
                        "Mean": f"{mean:.2f}",
                        "Std": f"{std:.2f}",
                        f"{int(confidence_level*100)}% CI": f"[{ci_low:.2f}, {ci_high:.2f}]"
                    })
        
        return pd.DataFrame(table_data)