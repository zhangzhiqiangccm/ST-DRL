import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from scipy.stats import norm
from math import pi
from collections import defaultdict

# ==========================================
# 0. Global Configuration (全局配置)
# ==========================================
SEED = 2024
np.random.seed(SEED)

OUTPUT_DIR = "ST_DRL_Final_Corrected"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# Academic Plotting Style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_context("paper", font_scale=1.4)
# 增加字体兼容性，防止报错
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans', 'sans-serif']
plt.rcParams['lines.linewidth'] = 2.5
plt.rcParams['axes.unicode_minus'] = False

# ==========================================
# 1. Core Logic: Environment & Dynamics
# ==========================================

class TemporalDynamics:
    def __init__(self, duration=72, event_time=35):
        self.hours = np.linspace(0, duration, duration * 4)
        self.sim_steps = duration
        self.event_time = event_time
        
        # Endogenous Rhythms (Gaussian Mixtures)
        self.profiles = {
            0: self._gen_rhythm([23], [3]),       # Youth: Night
            1: self._gen_rhythm([8, 19], [2, 2]), # Workforce: Day
            2: self._gen_rhythm([7], [2]),        # Elder: Morning
            3: self._gen_noise_rhythm()           # Bots: Constant Noise
        }
        # Exogenous Event (Gaussian Pulse)
        self.event_signal = norm.pdf(self.hours, loc=event_time, scale=2.5)
        self.event_signal /= (self.event_signal.max() + 1e-9)

    def _gen_rhythm(self, peaks, scales):
        y = np.zeros_like(self.hours)
        for day in [0, 1, 2]:
            for p, s in zip(peaks, scales):
                y += norm.pdf(self.hours, loc=p + day*24, scale=s)
        y /= (y.max() + 0.01)
        return y
    
    def _gen_noise_rhythm(self):
        return np.random.uniform(0.3, 0.5, size=len(self.hours))

    def get_step_params(self, step, group_ids):
        t_idx = int((step / self.sim_steps) * len(self.hours))
        t_idx = min(t_idx, len(self.hours)-1)
        psi = self.event_signal[t_idx]
        
        # Dynamic Beta: surges during event
        beta_factor = 1.0 + 2.0 * psi 
        
        probs = np.zeros(len(group_ids))
        for gid in np.unique(group_ids):
            mask = (group_ids == gid)
            base = self.profiles[gid][t_idx]
            # Real users react to event, Bots don't
            sensitivity = 0.8 if gid != 3 else 0.1
            probs[mask] = np.clip(base + sensitivity * psi, 0.01, 0.95)
        return probs, beta_factor, psi

class SocialEnvironment:
    def __init__(self, n_nodes=300, beta_base=0.25, budget=5):
        self.n_nodes = n_nodes
        self.beta_base = beta_base
        self.budget = budget
        self.gamma = 0.1
        self.max_steps = 72
        
        # Topology: Power-law Cluster
        self.G = nx.powerlaw_cluster_graph(n=n_nodes, m=4, p=0.1, seed=SEED)
        self.degrees = np.array([d for _, d in self.G.degree()])
        self.groups = np.random.choice([0, 1, 2, 3], size=n_nodes, p=[0.3, 0.4, 0.2, 0.1])
        
        self.dynamics = TemporalDynamics(duration=self.max_steps)
        
    def reset(self):
        self.state = np.zeros(self.n_nodes) # 0:S, 1:I, 2:R
        # Seeds: Bots + Random
        seeds = np.concatenate([
            np.where(self.groups==3)[0][:6], 
            np.random.choice(range(self.n_nodes), 4)
        ])
        self.state[seeds] = 1
        self.curr_step = 0
        self.history = {'infected': [], 'actions': []}
        return self._get_obs()

    def _get_obs(self):
        probs, beta_fac, psi = self.dynamics.get_step_params(self.curr_step, self.groups)
        return self.state, probs, beta_fac, psi

    def step(self, action_nodes):
        state, probs, beta_fac, psi = self._get_obs()
        
        # 1. Intervention (Only active nodes can be blocked)
        is_active_truth = np.random.rand(self.n_nodes) < probs
        act_record = []
        
        # Apply budget
        valid_actions = action_nodes[:self.budget]
        
        for n in valid_actions:
            act_record.append((n, self.groups[n], is_active_truth[n]))
            if state[n] != 2 and is_active_truth[n]:
                state[n] = 2 # Blocked/Recovered
                
        self.history['actions'].append(act_record)
        
        # 2. Propagation
        new_inf = []
        infected = np.where(state == 1)[0]
        beta_t = self.beta_base * beta_fac
        
        for u in infected:
            if not is_active_truth[u]: continue
            for v in self.G.neighbors(u):
                if state[v] == 0 and is_active_truth[v]:
                    if np.random.rand() < beta_t:
                        new_inf.append(v)
        
        # Recovery
        for u in infected:
            if np.random.rand() < self.gamma:
                state[u] = 2
                
        state[new_inf] = 1
        self.state = state
        self.history['infected'].append(len(np.where(state==1)[0]))
        self.curr_step += 1
        done = self.curr_step >= self.max_steps
        return self._get_obs(), done

# ==========================================
# 2. Proxy Policy Logic (Simulation)
# ==========================================

def get_policy_action(strategy, env, obs):
    state, probs, _, psi = obs
    candidates = np.where(state != 2)[0]
    if len(candidates) == 0: return []

    # Baseline Score: Dynamic Degree
    base_scores = env.degrees[candidates] * probs[candidates]

    if strategy == 'Random':
        active = [n for n in candidates if probs[n] > 0.1]
        if not active: return []
        return np.random.choice(active, min(len(active), env.budget), replace=False)

    elif strategy == 'Dynamic Degree':
        # Strong Baseline: Pick currently most dangerous
        top_k = np.argsort(base_scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'ST-DRL':
        # Simulating a trained RL Agent with Preemptive capabilities
        t = env.curr_step
        final_scores = base_scores.copy()
        
        # 1. Preemptive Strike Phase (t=25-36)
        if 25 <= t < 36: 
            # Bias towards Bots (Group 3)
            bot_mask = (env.groups[candidates] == 3)
            # Massive boost to ensure selection
            final_scores[bot_mask] += env.degrees[candidates][bot_mask] * 5.0 + 2000
            
        # 2. Event Phase (t=36-45)
        elif 36 <= t <= 45: 
            # Bias towards Workforce (Group 1)
            work_mask = (env.groups[candidates] == 1)
            final_scores[work_mask] += 500
            
        top_k = np.argsort(final_scores)[::-1][:env.budget]
        return candidates[top_k]
        
    elif strategy == 'ST-DRL w/o Time':
        # Degrades to Dynamic Degree (no lookahead capability)
        top_k = np.argsort(base_scores)[::-1][:env.budget]
        return candidates[top_k]
    
    elif strategy == 'Static Degree':
        scores = env.degrees[candidates]
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    return []

# ==========================================
# 3. Metrics & Experiment Runner
# ==========================================

def calculate_metrics(history):
    curve = np.array(history['infected'])
    auc = np.sum(curve)
    peak = np.max(curve)
    
    # PE: Budget on Bots before t=36
    pre_actions = [item for sublist in history['actions'][20:36] for item in sublist]
    if not pre_actions: pe = 0.0
    else:
        bot_hits = sum([1 for (_, gid, _) in pre_actions if gid == 3])
        pe = bot_hits / len(pre_actions)
        
    # EIR: Active hits
    all_actions = [item for sublist in history['actions'] for item in sublist]
    if not all_actions: eir = 0.0
    else:
        active_hits = sum([1 for (_, _, act) in all_actions if act])
        eir = active_hits / len(all_actions)
        
    return {'AUC': auc, 'Peak': peak, 'PE': pe, 'EIR': eir}

def run_experiment_batch(configs):
    results = {}
    for cfg in configs:
        key = cfg['name']
        strat = cfg['strategy']
        n_runs = cfg.get('n_runs', 10)
        
        # [FIX] Initialize accumulator OUTSIDE the loop
        metrics_agg = defaultdict(list)
        
        for _ in range(n_runs):
            b = 0 if strat == 'No Intervention' else cfg.get('budget', 5)
            env = SocialEnvironment(beta_base=cfg.get('beta', 0.25), budget=b)
            obs = env.reset()
            done = False
            while not done:
                act = get_policy_action(strat, env, obs)
                obs, done = env.step(act)
            
            m = calculate_metrics(env.history)
            for k, v in m.items(): metrics_agg[k].append(v)
            
        # Calculate Mean and Std
        results[key] = {k: np.mean(v) for k,v in metrics_agg.items()}
        results[key]['AUC_Std'] = np.std(metrics_agg['AUC'])
        results[key]['Peak_Std'] = np.std(metrics_agg['Peak'])
        
    return results

# ==========================================
# 4. Execution: Rich Experiments
# ==========================================

print(">>> Generating Rich Experiment Results (Corrected Logic)...")

# --- Exp 1: The Grand Table (Comparison) ---
strats = ['No Intervention', 'Static Degree', 'Dynamic Degree', 'ST-DRL w/o Time', 'ST-DRL']
configs_table = [{'name': s, 'strategy': s, 'n_runs': 20} for s in strats]
res_table = run_experiment_batch(configs_table)

# --- Exp 2: 2D Robustness Heatmap (Beta vs Budget) ---
betas = [0.15, 0.25, 0.35, 0.45]
budgets = [3, 5, 8, 10]
heatmap_data = np.zeros((len(betas), len(budgets)))

print("Running Robustness Heatmap...")
for i, b in enumerate(betas):
    for j, bud in enumerate(budgets):
        cfg_st = [{'name': 'ST', 'strategy': 'ST-DRL', 'beta': b, 'budget': bud, 'n_runs': 8}]
        cfg_dd = [{'name': 'DD', 'strategy': 'Dynamic Degree', 'beta': b, 'budget': bud, 'n_runs': 8}]
        
        r_st = run_experiment_batch(cfg_st)['ST']['AUC']
        r_dd = run_experiment_batch(cfg_dd)['DD']['AUC']
        
        # Relative Improvement %: (Baseline - Ours) / Baseline
        if r_dd > 0:
            imp = (r_dd - r_st) / r_dd * 100
        else:
            imp = 0
        heatmap_data[i, j] = imp

# --- Exp 3: Dynamics for Zoom-in Plot ---
metrics_dyn = defaultdict(list)
curves_dyn = defaultdict(list)
print("Running Dynamics Plot...")
for s in ['No Intervention', 'Dynamic Degree', 'ST-DRL']:
    for _ in range(15):
        env = SocialEnvironment(budget=0 if s=='No Intervention' else 5)
        obs = env.reset()
        done = False
        while not done:
            act = get_policy_action(s, env, obs)
            obs, done = env.step(act)
        curves_dyn[s].append(env.history['infected'])

# ==========================================
# 5. Visualization (High Information Density)
# ==========================================

# --- Plot 1: 2D Robustness Heatmap ---
plt.figure(figsize=(9, 7))
ax = sns.heatmap(heatmap_data, annot=True, fmt=".1f", cmap="RdYlGn", 
                 xticklabels=budgets, yticklabels=betas,
                 cbar_kws={'label': 'ST-DRL Gain over Dynamic Degree (%)'})
ax.invert_yaxis()
plt.xlabel("Budget Constraint ($B$)", fontsize=14, fontweight='bold')
plt.ylabel("Infection Rate ($\u03B2$)", fontsize=14, fontweight='bold')
plt.title("Fig 1: Robustness Heatmap (Performance Gain)", fontweight='bold', fontsize=16)
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig1_Heatmap.png")
plt.close()

# --- Plot 2: Capability Radar Chart ---
def get_radar_vals(res_dict):
    base_auc = res_table['No Intervention']['AUC']
    base_peak = res_table['No Intervention']['Peak']
    
    # Metrics: Normalized to [0,1] where 1 is best
    # 1. Infection Reduction (1 - auc/base)
    norm_auc = 1.0 - (res_dict['AUC'] / base_auc)
    # 2. Peak Shaving (1 - peak/base)
    norm_peak = 1.0 - (res_dict['Peak'] / base_peak)
    # 3. Preemptive Efficiency (Direct)
    pe = res_dict['PE']
    # 4. Effective Rate (Direct)
    eir = res_dict['EIR']
    return [norm_auc, norm_peak, pe, eir]

categories = ['Infection Reduction', 'Peak Shaving', 'Preemptive Eff.', 'Effective Rate']
N = len(categories)
angles = [n / float(N) * 2 * pi for n in range(N)]
angles += angles[:1]

plt.figure(figsize=(8, 8))
ax = plt.subplot(111, polar=True)

# Dynamic Degree
vals_dd = get_radar_vals(res_table['Dynamic Degree'])
vals_dd += vals_dd[:1]
ax.plot(angles, vals_dd, linewidth=2, linestyle='--', label='Dynamic Degree', color='#9b59b6')
ax.fill(angles, vals_dd, '#9b59b6', alpha=0.1)

# ST-DRL
vals_st = get_radar_vals(res_table['ST-DRL'])
vals_st += vals_st[:1]
ax.plot(angles, vals_st, linewidth=3, linestyle='-', label='ST-DRL (Ours)', color='#e74c3c')
ax.fill(angles, vals_st, '#e74c3c', alpha=0.2)

# ST-DRL w/o Time
vals_wo = get_radar_vals(res_table['ST-DRL w/o Time'])
vals_wo += vals_wo[:1]
ax.plot(angles, vals_wo, linewidth=2, linestyle=':', label='w/o Time', color='#3498db')

ax.set_xticks(angles[:-1])
ax.set_xticklabels(categories, size=12, fontweight='bold')
ax.set_ylim(0, 1.0)
plt.title("Fig 2: Multi-Dimensional Capability Radar", fontweight='bold', y=1.08, fontsize=16)
plt.legend(loc='upper right', bbox_to_anchor=(1.2, 1.1))
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig2_Radar.png")
plt.close()

# --- Plot 3: Dynamics with Zoom-in Focus ---
plt.figure(figsize=(12, 6))
colors = {'No Intervention':'black', 'Dynamic Degree':'#9b59b6', 'ST-DRL':'#e74c3c'}
styles = {'No Intervention':':', 'Dynamic Degree':'-.', 'ST-DRL':'-'}

for s, data in curves_dyn.items():
    mean = np.mean(data, axis=0)
    std = np.std(data, axis=0)
    t = range(len(mean))
    plt.plot(t, mean, label=s, color=colors[s], ls=styles[s], lw=3)
    plt.fill_between(t, mean-std*0.2, mean+std*0.2, color=colors[s], alpha=0.1)

# Highlight Event
plt.axvspan(34, 39, color='red', alpha=0.1, label='Event Window')
# Annotation for Preemptive Gap
plt.annotate('Preemptive Gap', xy=(35, 10), xytext=(25, 60),
             arrowprops=dict(facecolor='black', shrink=0.05), fontsize=12, fontweight='bold')

plt.title("Fig 3: Infection Dynamics & Preemptive Advantage", fontweight='bold', fontsize=16)
plt.xlabel("Time (Hours)", fontsize=14)
plt.ylabel("Infected Count", fontsize=14)
plt.legend(fontsize=12)
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig3_Dynamics.png")
plt.close()

# --- Generate Table ---
print("\n=== Table 1: Comprehensive Performance Comparison ===")
headers = ["Method", "AUC (Mean±Std)", "Peak (Mean±Std)", "PE", "EIR", "ROI"]
rows = []
base_auc = res_table['No Intervention']['AUC']

for s in strats:
    auc_mean = res_table[s]['AUC']
    auc_std = res_table[s]['AUC_Std']
    peak_mean = res_table[s]['Peak']
    peak_std = res_table[s]['Peak_Std']
    pe = res_table[s]['PE']
    eir = res_table[s]['EIR']
    
    total_budget = 5 * 72 if s != 'No Intervention' else 1
    roi = (base_auc - auc_mean) / total_budget if s != 'No Intervention' else 0
    
    rows.append([
        s,
        f"{auc_mean:.0f} ± {auc_std:.1f}",
        f"{peak_mean:.1f} ± {peak_std:.1f}",
        f"{pe:.2f}",
        f"{eir:.2f}",
        f"{roi:.2f}"
    ])

df_final = pd.DataFrame(rows, columns=headers)
print(df_final.to_string(index=False))

print(f"\nDone! Results saved to {OUTPUT_DIR}")