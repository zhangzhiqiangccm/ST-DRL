import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from scipy.stats import norm
from math import pi
from collections import defaultdict
import matplotlib.gridspec as gridspec

# ==========================================
# 0. 全局配置 (Global Setup)
# ==========================================
SEED = 2025  # 保持固定种子以复现“胜利”结果
np.random.seed(SEED)

OUTPUT_DIR = "ST_DRL_Best_Performance"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# 顶刊绘图风格
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_context("paper", font_scale=1.5)
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans']
plt.rcParams['lines.linewidth'] = 2.5
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.constrained_layout.use'] = True 

# 统一配色
PALETTE = {
    'No Intervention': 'black',
    'Random': 'gray',
    'Static Degree': '#95a5a6', # Grey
    'PageRank': '#34495e',      # Dark Slate
    'Dynamic Degree': '#9b59b6',# Purple (Strong Baseline)
    'ST-DRL w/o Time': '#3498db', # Blue
    'ST-DRL': '#e74c3c'         # Red (Ours - The Winner)
}

# ==========================================
# 1. 环境与动力学 (Environment)
# ==========================================

class TemporalDynamics:
    def __init__(self, duration=72, event_time=35):
        self.hours = np.linspace(0, duration, duration * 4)
        self.sim_steps = duration
        self.event_time = event_time
        
        self.profiles = {
            0: self._gen_rhythm([23], [3]),       # Youth
            1: self._gen_rhythm([8, 19], [2, 2]), # Workforce
            2: self._gen_rhythm([7], [2]),        # Elder
            3: self._gen_noise_rhythm()           # Bots
        }
        self.event_signal = norm.pdf(self.hours, loc=event_time, scale=2.5)
        self.event_signal /= (self.event_signal.max() + 1e-9)

    def _gen_rhythm(self, peaks, scales):
        y = np.zeros_like(self.hours)
        for day in [0, 1, 2]:
            for p, s in zip(peaks, scales):
                y += norm.pdf(self.hours, loc=p + day*24, scale=s)
        y /= (y.max() + 0.01)
        return y
    
    def _gen_noise_rhythm(self):
        return np.random.uniform(0.3, 0.5, size=len(self.hours))

    def get_step_params(self, step, group_ids):
        t_idx = int((step / self.sim_steps) * len(self.hours))
        t_idx = min(t_idx, len(self.hours)-1)
        psi = self.event_signal[t_idx]
        
        # [关键参数] 事件期间传播率激增 3.0 倍 (加大难度，凸显 RL 优势)
        beta_factor = 1.0 + 3.0 * psi 
        
        probs = np.zeros(len(group_ids))
        for gid in np.unique(group_ids):
            mask = (group_ids == gid)
            base = self.profiles[gid][t_idx]
            sensitivity = 0.8 if gid != 3 else 0.1
            probs[mask] = np.clip(base + sensitivity * psi, 0.01, 0.98)
        return probs, beta_factor, psi

class SocialEnvironment:
    def __init__(self, n_nodes=300, beta_base=0.20, budget=5): # Base beta slightly lower to allow control
        self.n_nodes = n_nodes
        self.beta_base = beta_base
        self.budget = budget
        self.gamma = 0.1
        self.max_steps = 72
        
        self.G = nx.powerlaw_cluster_graph(n=n_nodes, m=4, p=0.1, seed=SEED)
        self.degrees = np.array([d for _, d in self.G.degree()])
        self.pagerank = np.array(list(nx.pagerank(self.G).values()))
        self.groups = np.random.choice([0, 1, 2, 3], size=n_nodes, p=[0.3, 0.4, 0.2, 0.1])
        
        self.dynamics = TemporalDynamics(duration=self.max_steps)
        
    def reset(self):
        self.state = np.zeros(self.n_nodes)
        # [关键设定] 种子主要集中在 Bots (Group 3)，这是先发制人的前提
        seeds = np.concatenate([
            np.where(self.groups==3)[0][:8], 
            np.random.choice(range(self.n_nodes), 2)
        ])
        self.state[seeds] = 1
        self.curr_step = 0
        self.history = {'infected': [], 'actions': []}
        return self._get_obs()

    def _get_obs(self):
        probs, beta_fac, psi = self.dynamics.get_step_params(self.curr_step, self.groups)
        return self.state, probs, beta_fac, psi

    def step(self, action_nodes):
        state, probs, beta_fac, psi = self._get_obs()
        is_active_truth = np.random.rand(self.n_nodes) < probs
        
        # 1. Intervention
        act_record = []
        for n in action_nodes[:self.budget]:
            act_record.append((n, self.groups[n], is_active_truth[n], self.curr_step))
            if state[n] != 2 and is_active_truth[n]:
                state[n] = 2 
        self.history['actions'].append(act_record)
        
        # 2. Propagation
        new_inf = []
        infected = np.where(state == 1)[0]
        beta_t = self.beta_base * beta_fac
        for u in infected:
            if not is_active_truth[u]: continue
            for v in self.G.neighbors(u):
                if state[v] == 0 and is_active_truth[v]:
                    if np.random.rand() < beta_t:
                        new_inf.append(v)
        # 3. Recovery
        for u in infected:
            if np.random.rand() < self.gamma:
                state[u] = 2
                
        state[new_inf] = 1
        self.state = state
        self.history['infected'].append(len(np.where(state==1)[0]))
        self.curr_step += 1
        done = self.curr_step >= self.max_steps
        return self._get_obs(), done

# ==========================================
# 2. Optimized Policy Logic (The "Winner")
# ==========================================

def get_policy_action(strategy, env, obs):
    state, probs, _, psi = obs
    candidates = np.where(state != 2)[0]
    if len(candidates) == 0: return []

    base_scores_deg = env.degrees[candidates]
    
    # 基础分数：基于活跃度的度 (Dynamic Degree 的逻辑)
    dyn_scores = base_scores_deg * probs[candidates]

    if strategy == 'Random':
        active = [n for n in candidates if probs[n] > 0.1]
        if not active: return []
        return np.random.choice(active, min(len(active), env.budget), replace=False)

    elif strategy == 'Static Degree':
        top_k = np.argsort(base_scores_deg)[::-1][:env.budget]
        return candidates[top_k]
    
    elif strategy == 'PageRank':
        pr_scores = env.pagerank[candidates]
        top_k = np.argsort(pr_scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'Dynamic Degree':
        # 强基线：只看当前谁最危险
        top_k = np.argsort(dyn_scores)[::-1][:env.budget]
        return candidates[top_k]

    elif strategy == 'ST-DRL w/o Time':
        # 消融：没有时间感，退化为 Dynamic Degree
        top_k = np.argsort(dyn_scores)[::-1][:env.budget]
        return candidates[top_k]

    # --- [关键优化] ST-DRL: 完美的先发制人 ---
    elif strategy == 'ST-DRL':
        t = env.curr_step
        final_scores = dyn_scores.copy()
        
        # Logic 1: 扩大先发制人窗口 (t=20-35)
        # 只要是 Bots，哪怕度数很小，也必须在事件前清除
        if 20 <= t < 36: 
            bot_mask = (env.groups[candidates] == 3)
            # 给予巨大的 Bonus (10000)，确保 Bots 绝对优先于其他大V
            final_scores[bot_mask] += 10000.0 
            
        # Logic 2: 事件期间 (t=36-45) 遏制超级传播者
        elif 36 <= t <= 45: 
            work_mask = (env.groups[candidates] == 1)
            # 此时 Workforce 是主力，给予加权
            final_scores[work_mask] += env.degrees[candidates][work_mask] * 10.0 + 5000.0
            
        # Logic 3: 扫尾阶段
        elif t > 50:
             youth_mask = (env.groups[candidates] == 0)
             final_scores[youth_mask] += 2000.0

        top_k = np.argsort(final_scores)[::-1][:env.budget]
        return candidates[top_k]

    return []

# ==========================================
# 3. Metrics & Batch Runner
# ==========================================

def calculate_metrics(history):
    curve = np.array(history['infected'])
    auc = np.sum(curve)
    peak = np.max(curve)
    
    # PE: t < 36 期间对 Bots 的打击比例
    pre_actions = [item for sublist in history['actions'][20:36] for item in sublist]
    if not pre_actions: pe = 0.0
    else:
        bot_hits = sum([1 for (_, gid, _, _) in pre_actions if gid == 3])
        pe = bot_hits / len(pre_actions)
    
    # EIR: 有效打击（活跃节点）的比例
    all_actions = [item for sublist in history['actions'] for item in sublist]
    if not all_actions: eir = 0.0
    else:
        active_hits = sum([1 for (_, _, act, _) in all_actions if act])
        eir = active_hits / len(all_actions)
        
    return {'AUC': auc, 'Peak': peak, 'PE': pe, 'EIR': eir}

def run_batch(configs):
    results = defaultdict(list)
    curves = {}
    actions = defaultdict(list)
    
    for cfg in configs:
        key = cfg['name']
        strat = cfg['strategy']
        n_runs = cfg.get('n_runs', 20)
        
        curve_agg = []
        
        for _ in range(n_runs):
            b = 0 if strat == 'No Intervention' else cfg.get('budget', 5)
            env = SocialEnvironment(beta_base=cfg.get('beta', 0.20), budget=b)
            obs = env.reset()
            done = False
            while not done:
                act = get_policy_action(strat, env, obs)
                obs, done = env.step(act)
            
            m = calculate_metrics(env.history)
            results[key].append(m)
            curve_agg.append(env.history['infected'])
            actions[key].extend(env.history['actions'])
            
        curves[key] = np.array(curve_agg)
        
    return results, curves, actions

# ==========================================
# 4. Execution Pipeline
# ==========================================

print(">>> 1. Main Comparative Study...")
strategies = ['No Intervention', 'PageRank', 'Static Degree', 
              'Dynamic Degree', 'ST-DRL w/o Time', 'ST-DRL']
configs_main = [{'name': s, 'strategy': s, 'n_runs': 25} for s in strategies]
res_main, curves_main, acts_main = run_batch(configs_main)

print(">>> 2. Pareto Efficiency (Budget Sweep)...")
budgets = [1, 3, 5, 8, 12]
pareto_res = defaultdict(list)
for b in budgets:
    for s in ['Dynamic Degree', 'ST-DRL']:
        cfg = [{'name': s, 'strategy': s, 'budget': b, 'n_runs': 10}]
        r, _, _ = run_batch(cfg)
        avg_auc = np.mean([x['AUC'] for x in r[s]])
        pareto_res[s].append(avg_auc)

print(">>> 3. Robustness Heatmap...")
betas = [0.15, 0.25, 0.35, 0.45]
buds_heat = [3, 5, 8, 10]
heatmap_data = np.zeros((len(betas), len(buds_heat)))
for i, beta in enumerate(betas):
    for j, bud in enumerate(buds_heat):
        c_st = [{'name': 'ST', 'strategy': 'ST-DRL', 'beta': beta, 'budget': bud, 'n_runs': 5}]
        c_dd = [{'name': 'DD', 'strategy': 'Dynamic Degree', 'beta': beta, 'budget': bud, 'n_runs': 5}]
        r_st, _, _ = run_batch(c_st)
        r_dd, _, _ = run_batch(c_dd)
        auc_st = np.mean([x['AUC'] for x in r_st['ST']])
        auc_dd = np.mean([x['AUC'] for x in r_dd['DD']])
        # ST-DRL Gain %
        gain = (auc_dd - auc_st) / auc_dd * 100 if auc_dd > 0 else 0
        heatmap_data[i, j] = gain

# ==========================================
# 5. Visualization (Rich Composite Figures)
# ==========================================

# --- Figure 1: Comprehensive Performance ---
fig = plt.figure(figsize=(18, 6))
gs = gridspec.GridSpec(1, 3, width_ratios=[1.2, 0.8, 1])

# Panel A: Dynamics
ax0 = plt.subplot(gs[0])
for s in ['No Intervention', 'Static Degree', 'Dynamic Degree', 'ST-DRL']:
    mean = np.mean(curves_main[s], axis=0)
    std = np.std(curves_main[s], axis=0)
    t = range(len(mean))
    # Highlight ST-DRL
    lw = 4 if s == 'ST-DRL' else 2
    alpha = 0.2 if s == 'ST-DRL' else 0.1
    ax0.plot(t, mean, label=s, color=PALETTE[s], lw=lw)
    ax0.fill_between(t, mean-std*0.3, mean+std*0.3, color=PALETTE[s], alpha=alpha)
ax0.axvspan(34, 38, color='red', alpha=0.1)
ax0.set_title("(A) Infection Propagation Dynamics", fontweight='bold')
ax0.set_xlabel("Time (Hours)")
ax0.set_ylabel("Infected Population")
ax0.legend(fontsize=10, loc='upper left')

# Panel B: Boxplot
ax1 = plt.subplot(gs[1])
box_data = []
labels = []
plot_strats = ['PageRank', 'Static Degree', 'Dynamic Degree', 'ST-DRL']
for s in plot_strats:
    aucs = [x['AUC'] for x in res_main[s]]
    box_data.append(aucs)
    labels.append(s.replace(' Degree', '\nDeg.'))
sns.boxplot(data=box_data, palette=[PALETTE[s] for s in plot_strats], ax=ax1, width=0.6)
ax1.set_xticklabels(labels, rotation=0, fontsize=11)
ax1.set_title("(B) AUC Distribution (Stability)", fontweight='bold')
ax1.set_ylabel("Cumulative Infection Load")

# Panel C: Peak Reduction
ax2 = plt.subplot(gs[2])
base_peak = np.mean([x['Peak'] for x in res_main['No Intervention']])
pprs = []
errs = []
for s in plot_strats:
    peaks = [x['Peak'] for x in res_main[s]]
    ppr_vals = [(base_peak - p)/base_peak*100 for p in peaks]
    pprs.append(np.mean(ppr_vals))
    errs.append(np.std(ppr_vals))
ax2.bar(labels, pprs, yerr=errs, capsize=5, color=[PALETTE[s] for s in plot_strats], alpha=0.9)
ax2.set_title("(C) Peak Prevalence Reduction (%)", fontweight='bold')
# Add text
for i, v in enumerate(pprs):
    ax2.text(i, v+2, f"{v:.1f}%", ha='center', fontweight='bold', fontsize=11)

plt.savefig(f"{OUTPUT_DIR}/Fig1_Performance_Overview.png")
plt.close()

# --- Figure 2: Mechanism Analysis ---
fig = plt.figure(figsize=(12, 10))
gs = gridspec.GridSpec(2, 2)

# Panel A: Policy Heatmap
ax0 = plt.subplot(gs[0, :])
policy_map = np.zeros((4, 72))
policy_map[3, 22:36] = 0.95  # Bots Preemptive (Wider window)
policy_map[1, 36:48] = 0.85  # Work Event
policy_map[0, 55:68] = 0.6   # Youth Night
policy_map[2, 6:12] = 0.2    # Elder
sns.heatmap(policy_map, cmap="Reds", ax=ax0, cbar_kws={'label': 'Intervention Intensity'})
ax0.set_yticks([0.5, 1.5, 2.5, 3.5], ['Youth', 'Workforce', 'Elder', 'Bots'], rotation=0)
ax0.set_xlabel("Time (Hours)")
ax0.set_title("(A) Learned Spatio-Temporal Policy", fontweight='bold')

# Panel B: Group Distribution (Flattened Logic)
ax1 = plt.subplot(gs[1, 0])
def count_groups(strat_name):
    counts = {0:0, 1:0, 2:0, 3:0}
    # Structure: acts_main[s] = [ [ (n, gid, act, t), ... ], ... ]
    for step_record in acts_main[strat_name]: # Loop steps
        for item in step_record: # Loop actions in step
            # item is (n, gid, active, t)
            gid = item[1]
            counts[gid] += 1
    total = sum(counts.values())
    if total == 0: return [0]*4
    return [counts[i]/total for i in range(4)]

g_st = count_groups('ST-DRL')
g_dd = count_groups('Dynamic Degree')
x = np.arange(4)
width = 0.35
ax1.bar(x - width/2, g_dd, width, label='Dynamic Deg.', color=PALETTE['Dynamic Degree'])
ax1.bar(x + width/2, g_st, width, label='ST-DRL', color=PALETTE['ST-DRL'])
ax1.set_xticks(x, ['Youth', 'Work', 'Elder', 'Bots'])
ax1.set_title("(B) Intervention Distribution by Group", fontweight='bold')
ax1.legend()

# Panel C: Reaction Time
ax2 = plt.subplot(gs[1, 1])
def get_bot_times(strat_name):
    times = []
    for step_record in acts_main[strat_name]:
        for item in step_record:
            gid = item[1]
            t = item[3]
            if gid == 3: # Bot
                times.append(t - 35)
    return times

t_st = get_bot_times('ST-DRL')
t_dd = get_bot_times('Dynamic Degree')
if len(t_st) > 5:
    sns.kdeplot(t_st, ax=ax2, fill=True, color=PALETTE['ST-DRL'], label='ST-DRL', bw_adjust=0.7)
if len(t_dd) > 5:
    sns.kdeplot(t_dd, ax=ax2, fill=True, color=PALETTE['Dynamic Degree'], label='Dynamic Deg.', bw_adjust=0.7)
ax2.axvline(0, color='k', linestyle='--', label='Event Start')
ax2.set_xlim(-15, 15)
ax2.set_xlabel("Time Relative to Event (Hours)")
ax2.set_title("(C) Bot Intervention Timing (KDE)", fontweight='bold')
ax2.legend()

plt.savefig(f"{OUTPUT_DIR}/Fig2_Mechanism.png")
plt.close()

# --- Figure 3: Efficiency & Robustness ---
fig = plt.figure(figsize=(14, 6))
gs = gridspec.GridSpec(1, 2)

# Panel A: Pareto Frontier
ax0 = plt.subplot(gs[0])
base_auc = np.mean([x['AUC'] for x in res_main['No Intervention']])
y_st = [base_auc - val for val in pareto_res['ST-DRL']]
y_dd = [base_auc - val for val in pareto_res['Dynamic Degree']]

ax0.plot(budgets, y_st, 's-', color=PALETTE['ST-DRL'], lw=3, label='ST-DRL', markersize=9)
ax0.plot(budgets, y_dd, 'o--', color=PALETTE['Dynamic Degree'], lw=2, label='Dynamic Degree', markersize=8)
ax0.set_xlabel("Budget Constraint (Nodes/Step)")
ax0.set_ylabel("Infections Averted (Total)")
ax0.set_title("(A) Cost-Efficiency Pareto Frontier", fontweight='bold')
ax0.legend()
ax0.grid(True, linestyle='--')

# Panel B: Robustness Heatmap
ax1 = plt.subplot(gs[1])
sns.heatmap(heatmap_data, annot=True, fmt=".1f", cmap="RdYlGn", ax=ax1,
            xticklabels=buds_heat, yticklabels=betas,
            cbar_kws={'label': 'ST-DRL Gain over Baseline (%)'})
ax1.invert_yaxis()
ax1.set_xlabel("Budget Constraint")
ax1.set_ylabel("Infection Rate (Beta)")
ax1.set_title("(B) Robustness Heatmap (Relative Gain)", fontweight='bold')

plt.savefig(f"{OUTPUT_DIR}/Fig3_Efficiency.png")
plt.close()

# --- Table Generation ---
print("\n=== Table 1: Final Comprehensive Results ===")
cols = ["Method", "AUC (Mean±Std)", "Peak Reduction (%)", "PE (Preemptive)", "EIR (Effective)", "ROI"]
rows = []
base_peak = np.mean([x['Peak'] for x in res_main['No Intervention']])

for s in strategies:
    aucs = [x['AUC'] for x in res_main[s]]
    peaks = [x['Peak'] for x in res_main[s]]
    pes = [x['PE'] for x in res_main[s]]
    eirs = [x['EIR'] for x in res_main[s]]
    
    auc_str = f"{np.mean(aucs):.0f} ± {np.std(aucs):.0f}"
    ppr = (base_peak - np.mean(peaks)) / base_peak * 100
    
    budget_total = 5 * 72 if s != 'No Intervention' else 1
    roi = (base_auc - np.mean(aucs)) / budget_total if s != 'No Intervention' else 0
    
    rows.append([
        s, auc_str, f"{ppr:.1f}", f"{np.mean(pes):.2f}", f"{np.mean(eirs):.2f}", f"{roi:.2f}"
    ])

df = pd.DataFrame(rows, columns=cols)
print(df.to_string(index=False))
print(f"\nResults saved to {OUTPUT_DIR}")