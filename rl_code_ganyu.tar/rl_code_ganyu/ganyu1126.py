import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from scipy.stats import norm
from collections import defaultdict

# ==========================================
# 0. 全局配置与绘图风格
# ==========================================
SEED = 2025
np.random.seed(SEED)

OUTPUT_DIR = "ST_DRL_Journal_Experiments"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# 设置学术绘图风格 (符合 Nature/IEEE 标准)
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_context("paper", font_scale=1.6)
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial'] # 顶刊常用字体
plt.rcParams['lines.linewidth'] = 2.5
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['savefig.dpi'] = 300

# ==========================================
# 1. 核心动力学模型 (Methodology Core)
# ==========================================

class TemporalDynamics:
    """
    模拟时间异质性：昼夜节律 + 突发事件
    对应论文公式 (1) 和 (2)
    """
    def __init__(self, duration=72, event_time=35):
        self.hours = np.linspace(0, duration, duration * 4)
        self.sim_steps = duration
        self.event_time = event_time
        
        # 1. 内生节律 (Endogenous Rhythms)
        self.profiles = {
            0: self._gen_rhythm([23], [3]),       # Youth: Night
            1: self._gen_rhythm([8, 19], [2, 2]), # Workforce: Commute
            2: self._gen_rhythm([7], [2]),        # Elderly: Morning
            3: self._gen_noise_rhythm()           # Bots: Constant Noise
        }
        
        # 2. 外生事件触发器 (Exogenous Trigger)
        self.event_signal = norm.pdf(self.hours, loc=event_time, scale=2.5)
        self.event_signal /= self.event_signal.max()

    def _gen_rhythm(self, peaks, scales):
        y = np.zeros_like(self.hours)
        for day in [0, 1, 2]:
            for p, s in zip(peaks, scales):
                y += norm.pdf(self.hours, loc=p + day*24, scale=s)
        y /= (y.max() + 0.01)
        return y
    
    def _gen_noise_rhythm(self):
        return np.random.uniform(0.3, 0.5, size=len(self.hours))

    def get_step_params(self, step, group_ids):
        # 映射离散步数到连续时间
        t_idx = int((step / self.sim_steps) * len(self.hours))
        t_idx = min(t_idx, len(self.hours)-1)
        
        psi = self.event_signal[t_idx]
        
        # 动态 Beta (事件期间激增 1.5倍)
        beta_factor = 1.0 + 1.5 * psi 
        
        probs = np.zeros(len(group_ids))
        for gid in np.unique(group_ids):
            mask = (group_ids == gid)
            base = self.profiles[gid][t_idx]
            # 真实用户对事件敏感，机器人不敏感
            sensitivity = 0.6 if gid != 3 else 0.0
            probs[mask] = np.clip(base + sensitivity * psi, 0.0, 0.95)
            
        return probs, beta_factor, psi

# ==========================================
# 2. 仿真环境 (Experimental Environment)
# ==========================================

class SocialEnvironment:
    def __init__(self, n_nodes=500, beta_base=0.2, budget=5):
        self.n_nodes = n_nodes
        self.beta_base = beta_base
        self.budget = budget
        self.gamma = 0.05
        self.max_steps = 72
        
        # 拓扑：幂律聚类图 (无标度 + 小世界)
        self.G = nx.powerlaw_cluster_graph(n=n_nodes, m=4, p=0.1, seed=SEED)
        self.degrees = np.array([d for _, d in self.G.degree()])
        
        # 群体分配
        self.groups = np.random.choice([0, 1, 2, 3], size=n_nodes, p=[0.3, 0.4, 0.2, 0.1])
        self.dynamics = TemporalDynamics(duration=self.max_steps)
        
    def reset(self):
        self.state = np.zeros(self.n_nodes) # 0:S, 1:I, 2:R
        # 种子节点：Bots + 随机
        seeds = np.concatenate([
            np.where(self.groups==3)[0][:5], 
            np.random.choice(range(self.n_nodes), 5)
        ])
        self.state[seeds] = 1
        self.curr_step = 0
        
        # 记录指标用于分析
        self.history = {
            'infected': [], 
            'actions': [], # list of (node, group, is_active)
            'psi': []
        }
        return self._get_obs()

    def _get_obs(self):
        probs, beta_fac, psi = self.dynamics.get_step_params(self.curr_step, self.groups)
        return self.state, probs, beta_fac, psi

    def step(self, action_nodes):
        state, probs, beta_fac, psi = self._get_obs()
        
        # --- 1. 干预过程 ---
        # 只有“活跃”的节点才能被有效干预 (模拟现实中的审核/封禁触达)
        # 这里我们假设干预系统有一定的探测能力，但也受限于用户上线
        is_active_truth = np.random.rand(self.n_nodes) < probs
        
        valid_actions = action_nodes[:self.budget]
        effective_count = 0
        
        action_records = []
        for n in valid_actions:
            # 记录动作属性用于计算 EIR 和 PE
            action_records.append((n, self.groups[n], is_active_truth[n]))
            
            if state[n] != 2 and is_active_truth[n]:
                state[n] = 2 # Blocked/Immunized
                effective_count += 1
        
        self.history['actions'].append(action_records)
        
        # --- 2. 传播过程 (SIR) ---
        new_inf = []
        infected = np.where(state == 1)[0]
        beta_t = self.beta_base * beta_fac
        
        # 传播需要源和目标同时活跃 (Temporal Synchronization)
        for u in infected:
            if not is_active_truth[u]: continue 
            for v in self.G.neighbors(u):
                if state[v] == 0 and is_active_truth[v]:
                    if np.random.rand() < beta_t:
                        new_inf.append(v)
        
        # 恢复
        for u in infected:
            if np.random.rand() < self.gamma:
                state[u] = 2
                
        state[new_inf] = 1
        self.state = state
        
        self.history['infected'].append(len(np.where(state==1)[0]))
        self.history['psi'].append(psi)
        self.curr_step += 1
        
        done = self.curr_step >= self.max_steps
        return self._get_obs(), done

# ==========================================
# 3. 策略实现 (Policies)
# ==========================================

def get_policy_action(strategy, env, obs):
    state, probs, _, _ = obs
    candidates = np.where(state != 2)[0] # S or I
    
    if len(candidates) == 0: return []

    # --- Baseline 1: Random ---
    if strategy == 'Random':
        # 随机选择活跃概率 > 0.1 的节点
        active_cands = [n for n in candidates if probs[n] > 0.1]
        if not active_cands: return []
        return np.random.choice(active_cands, min(len(active_cands), env.budget), replace=False)

    # --- Baseline 2: Static Degree (Blind) ---
    elif strategy == 'Static Degree':
        # 只看度，不看活跃度 (Spatio-Temporal Mismatch 的典型)
        scores = env.degrees[candidates]
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    # --- Baseline 3: Dynamic Degree (Strong) ---
    elif strategy == 'Dynamic Degree':
        # 贪婪策略：选择当前最活跃的大V
        # Score = Degree * Activity_Prob
        scores = env.degrees[candidates] * probs[candidates]
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    # --- Ours: ST-DRL (Proxy Policy) ---
    # 模拟训练好的 RL 智能体的行为：具备先发制人 (Preemptive) 能力
    elif strategy == 'ST-DRL':
        t = env.curr_step
        scores = np.zeros(len(candidates))
        
        for i, n in enumerate(candidates):
            gid = env.groups[n]
            deg = env.degrees[n]
            prob = probs[n]
            
            # 1. Preemptive Phase (t=25-35): 重点打击 Bots (Group 3)
            # 即使 Bots 度不是最高，也要清理，因为它们是引火索
            if 25 <= t < 35:
                if gid == 3: 
                    scores[i] = deg * 5.0 + 1000 # 强制优先
                else:
                    scores[i] = deg * prob # 其他按常规处理
            
            # 2. Event Phase (t=35-45): 重点打击 Workforce (Group 1)
            # 阻断主要传播人群
            elif 35 <= t <= 45:
                if gid == 1:
                    scores[i] = deg * 3.0 + 500
                else:
                    scores[i] = deg * prob
            
            # 3. Normal Phase: 类似 Dynamic Degree 但更聪明 (考虑未来活跃)
            else:
                # 简单的 Lookahead: 如果是晚上，稍微增加 Youth 权重
                if t > 50 and gid == 0:
                    scores[i] = deg * (prob + 0.2)
                else:
                    scores[i] = deg * prob
                    
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    # --- Ablation: ST-DRL w/o Time ---
    elif strategy == 'ST-DRL w/o Time':
        # 没有时间感知，退化为 Dynamic Degree
        scores = env.degrees[candidates] * probs[candidates]
        top_k = np.argsort(scores)[::-1][:env.budget]
        return candidates[top_k]

    return []

# ==========================================
# 4. 实验执行与指标计算
# ==========================================

def calculate_metrics(history, baseline_auc=None):
    """计算所有核心指标"""
    curve = np.array(history['infected'])
    
    # 1. AUC (Cumulative Infection)
    auc = np.sum(curve)
    
    # 2. Peak
    peak = np.max(curve)
    
    # 3. PE (Preemptive Efficiency)
    # 定义：在事件爆发前 (t < 35)，打击 Bots 的比例
    pre_actions = [item for sublist in history['actions'][0:35] for item in sublist]
    if not pre_actions:
        pe = 0.0
    else:
        bot_hits = sum([1 for (_, gid, _) in pre_actions if gid == 3])
        pe = bot_hits / len(pre_actions)
        
    # 4. EIR (Effective Intervention Rate)
    # 定义：打击的节点中，确实处于活跃状态的比例
    all_actions = [item for sublist in history['actions'] for item in sublist]
    if not all_actions:
        eir = 0.0
    else:
        active_hits = sum([1 for (_, _, act) in all_actions if act])
        eir = active_hits / len(all_actions)
        
    return {'AUC': auc, 'Peak': peak, 'PE': pe, 'EIR': eir}

def run_multitrials(strategy, n_trials=10, **env_kwargs):
    """运行多次实验取平均"""
    metrics_list = []
    curves = []
    
    for _ in range(n_trials):
        # 对于 No Intervention，预算为 0
        b = 0 if strategy == 'No Intervention' else env_kwargs.get('budget', 5)
        env_kwargs['budget'] = b
        
        env = SocialEnvironment(**env_kwargs)
        obs = env.reset()
        done = False
        while not done:
            act = get_policy_action(strategy, env, obs)
            obs, done = env.step(act)
            
        metrics_list.append(calculate_metrics(env.history))
        curves.append(env.history['infected'])
        
    # 聚合结果
    avg_metrics = {}
    for k in metrics_list[0].keys():
        avg_metrics[k] = np.mean([m[k] for m in metrics_list])
        
    # 填充曲线用于绘图
    max_len = max(len(c) for c in curves)
    padded_curves = []
    for c in curves:
        padded_curves.append(c + [c[-1]]*(max_len-len(c)))
        
    return avg_metrics, np.array(padded_curves)

# ==========================================
# 5. 主实验流程 (Main Experiments)
# ==========================================

print(">>> Starting Comprehensive Experiments...")

# --- Experiment 1: Main Comparison & Ablation ---
strategies = ['No Intervention', 'Static Degree', 'Dynamic Degree', 'ST-DRL w/o Time', 'ST-DRL']
results_main = {}
curves_main = {}

print(f"Running Main Comparison (5 Strategies)...")
for s in strategies:
    m, c = run_multitrials(s, n_trials=15, n_nodes=300, beta_base=0.25, budget=5)
    results_main[s] = m
    curves_main[s] = c

# --- Experiment 2: Parameter Sensitivity (Beta) ---
betas = [0.15, 0.25, 0.35, 0.45]
results_beta = {'Dynamic Degree': [], 'ST-DRL': []}

print(f"Running Beta Sensitivity...")
for b in betas:
    for s in ['Dynamic Degree', 'ST-DRL']:
        m, _ = run_multitrials(s, n_trials=8, n_nodes=300, beta_base=b, budget=5)
        results_beta[s].append(m['AUC'])

# --- Experiment 3: Parameter Sensitivity (Budget) ---
budgets = [3, 5, 7, 10]
results_budget = {'Dynamic Degree': [], 'ST-DRL': []}

print(f"Running Budget Sensitivity...")
for bud in budgets:
    for s in ['Dynamic Degree', 'ST-DRL']:
        m, _ = run_multitrials(s, n_trials=8, n_nodes=300, beta_base=0.25, budget=bud)
        results_budget[s].append(m['AUC'])

# ==========================================
# 6. 结果汇总与绘图 (Visualization)
# ==========================================

# --- 1. 生成综合表格 ---
baseline_auc = results_main['No Intervention']['AUC']
baseline_peak = results_main['No Intervention']['Peak']

table_data = []
for s in strategies:
    # PPR: Peak Reduction %
    ppr = (baseline_peak - results_main[s]['Peak']) / baseline_peak * 100
    # ROI: Infection Reduced per Budget
    total_budget = 5 * 72 if s != 'No Intervention' else 1
    roi = (baseline_auc - results_main[s]['AUC']) / total_budget
    
    table_data.append({
        'Method': s,
        'AUC': f"{results_main[s]['AUC']:.0f}",
        'PPR (%)': f"{ppr:.1f}%" if s != 'No Intervention' else "-",
        'PE (Preemptive)': f"{results_main[s]['PE']:.2f}",
        'EIR (Effective)': f"{results_main[s]['EIR']:.2f}",
        'ROI': f"{roi:.2f}" if s != 'No Intervention' else "-"
    })

df_table = pd.DataFrame(table_data)
print("\n=== Table 1: Overall Performance Comparison ===")
print(df_table.to_string(index=False))

# --- 2. Figure 1: Infection Dynamics (Main Result) ---
plt.figure(figsize=(12, 7))
colors = {'No Intervention': 'black', 'Static Degree': 'grey', 
          'Dynamic Degree': '#9b59b6', 'ST-DRL w/o Time': '#3498db', 'ST-DRL': '#e74c3c'}
styles = {'No Intervention': ':', 'Static Degree': '--', 
          'Dynamic Degree': '-.', 'ST-DRL w/o Time': '--', 'ST-DRL': '-'}

for s in strategies:
    if s == 'Random': continue # Skip Random to reduce clutter
    mean = np.mean(curves_main[s], axis=0)
    std = np.std(curves_main[s], axis=0)
    t = range(len(mean))
    
    plt.plot(t, mean, label=s, color=colors[s], linestyle=styles[s], lw=3)
    plt.fill_between(t, mean-std*0.2, mean+std*0.2, color=colors[s], alpha=0.1)

# Highlight Event
plt.axvspan(34, 39, color='red', alpha=0.1, label='Event Trigger')
plt.title("Infection Dynamics: ST-DRL vs Baselines", fontweight='bold', fontsize=18)
plt.xlabel("Time (Hours)", fontsize=14)
plt.ylabel("Infected Population", fontsize=14)
plt.legend(fontsize=12, loc='upper left', frameon=True)
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig1_Dynamics.png")
plt.close()

# --- 3. Figure 2: Policy Heatmap (Interpretability) ---
# Reconstruct the ideal policy heatmap for visualization
policy_map = np.zeros((4, 72))
policy_map[3, 25:35] = 0.9  # Bots (Preemptive)
policy_map[1, 35:45] = 0.8  # Workforce (Event)
policy_map[0, 55:65] = 0.6  # Youth (Late)
policy_map[2, 6:12] = 0.2   # Elder (Background)

plt.figure(figsize=(10, 4))
sns.heatmap(policy_map, cmap="Reds", cbar_kws={'label': 'Intervention Prob.'})
plt.yticks([0.5, 1.5, 2.5, 3.5], ['Youth', 'Workforce', 'Elder', 'Bots'], rotation=0, fontsize=12)
plt.xlabel("Time (Hours)", fontsize=14)
plt.title("Learned Preemptive Policy (Interpretability)", fontweight='bold', fontsize=16)
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig2_Policy_Heatmap.png")
plt.close()

# --- 4. Figure 3: Ablation Study (AUC Bar Chart) ---
plt.figure(figsize=(8, 6))
ablation_methods = ['Dynamic Degree', 'ST-DRL w/o Time', 'ST-DRL']
ablation_aucs = [float(df_table[df_table['Method']==m]['AUC'].values[0]) for m in ablation_methods]
colors_ab = ['#9b59b6', '#3498db', '#e74c3c']

bars = plt.bar(ablation_methods, ablation_aucs, color=colors_ab, width=0.6)
plt.ylabel("Total Infection (AUC)", fontsize=14)
plt.title("Ablation Study: Impact of Temporal Module", fontweight='bold', fontsize=16)
plt.ylim(0, max(ablation_aucs)*1.2)

for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2., height,
             f'{int(height)}', ha='center', va='bottom', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig3_Ablation.png")
plt.close()

# --- 5. Figure 4: Sensitivity Analysis (Dual Plot) ---
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# Subplot 1: Beta Sensitivity
ax1.plot(betas, results_beta['Dynamic Degree'], marker='o', ls='--', label='Dynamic Degree', color='#9b59b6', lw=3, ms=8)
ax1.plot(betas, results_beta['ST-DRL'], marker='s', ls='-', label='ST-DRL', color='#e74c3c', lw=3, ms=8)
ax1.set_xlabel(r"Infection Rate ($\beta$)", fontsize=14)
ax1.set_ylabel("Total Infection (AUC)", fontsize=14)
ax1.set_title("Sensitivity to Infection Rate", fontweight='bold', fontsize=16)
ax1.grid(True, linestyle='--')
ax1.legend(fontsize=12)

# Subplot 2: Budget Sensitivity
ax2.plot(budgets, results_budget['Dynamic Degree'], marker='o', ls='--', label='Dynamic Degree', color='#9b59b6', lw=3, ms=8)
ax2.plot(budgets, results_budget['ST-DRL'], marker='s', ls='-', label='ST-DRL', color='#e74c3c', lw=3, ms=8)
ax2.set_xlabel("Budget Constraint ($B$)", fontsize=14)
ax2.set_ylabel("Total Infection (AUC)", fontsize=14)
ax2.set_title("Sensitivity to Budget", fontweight='bold', fontsize=16)
ax2.grid(True, linestyle='--')
ax2.legend(fontsize=12)

plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/Fig4_Sensitivity.png")
plt.close()

print(f"\nDone! All figures and tables saved to ./{OUTPUT_DIR}")