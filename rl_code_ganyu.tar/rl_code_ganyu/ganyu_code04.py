import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import random
from enum import Enum
from typing import Dict, List, Tuple, Optional, Callable
import matplotlib.dates as mdates
from matplotlib.dates import DateFormatter
from scipy import interpolate
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import pandas as pd
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
import warnings
import time
warnings.filterwarnings('ignore')

# 设置matplotlib支持中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class UserAgeGroup(Enum):
    """
    用户年龄分组枚举 - 更细粒度
    """
    TEEN = "teen"        # 青少年 (13-19岁)
    YOUNG_ADULT = "young_adult"  # 年轻成人 (20-29岁)
    ADULT = "adult"      # 成人 (30-39岁)
    MIDDLE_ADULT = "middle_adult" # 中年成人 (40-49岁)
    MATURE_ADULT = "mature_adult" # 成熟成人 (50-59岁)
    SENIOR = "senior"    # 老年 (60-70岁)

class TimeSlot(Enum):
    """
    时间段枚举 - 更细粒度
    """
    EARLY_MORNING = "early_morning"  # 凌晨 (0:00-4:00)
    DAWN = "dawn"        # 黎明 (4:00-8:00)
    MORNING = "morning"  # 上午 (8:00-12:00)
    NOON = "noon"        # 中午 (12:00-14:00)
    AFTERNOON = "afternoon" # 下午 (14:00-18:00)
    EVENING = "evening"  # 傍晚 (18:00-21:00)
    NIGHT = "night"      # 夜晚 (21:00-24:00)

class GrowthPhase(Enum):
    """
    传播增长阶段枚举
    """
    SLOW_START = "slow_start"      # 缓慢发展期
    RAPID_GROWTH = "rapid_growth"  # 快速发展期
    STABLE = "stable"              # 平稳期

class InterventionType(Enum):
    """
    干预类型枚举
    """
    BLOCK = "block"        # 阻断传播
    REDUCE = "reduce"      # 降低传播概率
    PROMOTE = "promote"    # 促进传播（反向干预）

class InterventionEnvironment:
    """
    信息传播干预环境
    """
    
    def __init__(self, 
                 network_size: int = 1000,
                 start_time: datetime = datetime(2025, 11, 14, 0, 0),
                 simulation_days: int = 5,
                 growth_phases: Optional[List[Tuple[GrowthPhase, timedelta]]] = None,
                 predefined_age_distribution: Optional[Dict[UserAgeGroup, float]] = None,
                 predefined_time_parameters: Optional[Dict] = None,
                 max_interventions: int = 100,
                 seed_ratio: float = 0.005):
        """
        初始化干预环境
        
        Args:
            network_size: 网络节点数量
            start_time: 模拟开始时间
            simulation_days: 模拟天数
            growth_phases: 增长阶段配置 [(阶段, 持续时间), ...]
            predefined_age_distribution: 预定义年龄分布
            predefined_time_parameters: 预定义时间参数
            max_interventions: 最大干预次数
            seed_ratio: 种子节点比例
        """
        self.network_size = network_size
        self.start_time = start_time
        self.end_time = start_time + timedelta(days=simulation_days)
        self.current_time = start_time
        self.max_interventions = max_interventions
        self.seed_ratio = seed_ratio
        
        # 构建社交网络
        self.network = self._build_network()
        
        # 初始化用户特征
        self.users = self._initialize_users(predefined_age_distribution)
        
        # 信息传播状态 (0: 未传播, 1: 已传播)
        self.information_state = {node: 0 for node in self.network.nodes()}
        
        # 记录传播轨迹
        self.propagation_history = []
        
        # 干预记录
        self.intervention_history = []
        
        # 增长阶段配置
        if growth_phases is None:
            self.growth_phases = [
                (GrowthPhase.SLOW_START, timedelta(days=1)),
                (GrowthPhase.RAPID_GROWTH, timedelta(days=2)),
                (GrowthPhase.STABLE, timedelta(days=2))
            ]
        else:
            self.growth_phases = growth_phases
        
        # 计算各阶段的时间边界
        self.phase_boundaries = self._calculate_phase_boundaries()
        
        # 不同时间段的传播参数
        if predefined_time_parameters is None:
            self.time_params = self._create_default_time_parameters()
        else:
            self.time_params = predefined_time_parameters
        
        # 不同年龄组的传播倾向
        self.age_propagation_tendency = {
            UserAgeGroup.TEEN: 1.5,
            UserAgeGroup.YOUNG_ADULT: 1.4,
            UserAgeGroup.ADULT: 1.2,
            UserAgeGroup.MIDDLE_ADULT: 1.0,
            UserAgeGroup.MATURE_ADULT: 0.8,
            UserAgeGroup.SENIOR: 0.6
        }
        
        # 年龄组在不同时间段的活跃度
        self.age_time_activity = self._create_age_time_activity_matrix()
        
        # 干预成本矩阵
        self.intervention_costs = self._create_intervention_cost_matrix()
        
        # 当前干预状态
        self.node_intervention_status = {node: {
            'type': None,
            'remaining_duration': 0,
            'effectiveness': 0.0
        } for node in self.network.nodes()}
    
    def _create_intervention_cost_matrix(self) -> Dict:
        """
        创建干预成本矩阵
        """
        costs = {
            'block': {
                'base_cost': 10.0,
                'age_multipliers': {
                    UserAgeGroup.TEEN: 1.5,        # 青少年干预成本高
                    UserAgeGroup.YOUNG_ADULT: 1.2, # 年轻成人干预成本较高
                    UserAgeGroup.ADULT: 1.0,       # 成人基准成本
                    UserAgeGroup.MIDDLE_ADULT: 0.9, # 中年成本略低
                    UserAgeGroup.MATURE_ADULT: 0.8, # 成熟成人成本较低
                    UserAgeGroup.SENIOR: 0.7       # 老年成本最低
                },
                'time_multipliers': {
                    TimeSlot.EARLY_MORNING: 2.0,   # 凌晨干预成本高
                    TimeSlot.DAWN: 1.5,           # 黎明成本较高
                    TimeSlot.MORNING: 1.0,        # 上午基准成本
                    TimeSlot.NOON: 0.9,           # 中午成本略低
                    TimeSlot.AFTERNOON: 0.8,      # 下午成本较低
                    TimeSlot.EVENING: 1.0,        # 傍晚基准成本
                    TimeSlot.NIGHT: 1.8           # 夜晚成本较高
                }
            },
            'reduce': {
                'base_cost': 5.0,
                'age_multipliers': {
                    UserAgeGroup.TEEN: 1.2,
                    UserAgeGroup.YOUNG_ADULT: 1.1,
                    UserAgeGroup.ADULT: 1.0,
                    UserAgeGroup.MIDDLE_ADULT: 0.9,
                    UserAgeGroup.MATURE_ADULT: 0.8,
                    UserAgeGroup.SENIOR: 0.7
                },
                'time_multipliers': {
                    TimeSlot.EARLY_MORNING: 1.8,
                    TimeSlot.DAWN: 1.3,
                    TimeSlot.MORNING: 1.0,
                    TimeSlot.NOON: 0.9,
                    TimeSlot.AFTERNOON: 0.8,
                    TimeSlot.EVENING: 1.0,
                    TimeSlot.NIGHT: 1.5
                }
            },
            'promote': {
                'base_cost': 8.0,
                'age_multipliers': {
                    UserAgeGroup.TEEN: 1.0,
                    UserAgeGroup.YOUNG_ADULT: 0.9,
                    UserAgeGroup.ADULT: 1.0,
                    UserAgeGroup.MIDDLE_ADULT: 1.1,
                    UserAgeGroup.MATURE_ADULT: 1.2,
                    UserAgeGroup.SENIOR: 1.3
                },
                'time_multipliers': {
                    TimeSlot.EARLY_MORNING: 2.5,
                    TimeSlot.DAWN: 2.0,
                    TimeSlot.MORNING: 1.2,
                    TimeSlot.NOON: 1.0,
                    TimeSlot.AFTERNOON: 0.9,
                    TimeSlot.EVENING: 1.1,
                    TimeSlot.NIGHT: 2.2
                }
            }
        }
        return costs
    
    def _create_age_time_activity_matrix(self) -> Dict[TimeSlot, Dict[UserAgeGroup, float]]:
        """
        创建年龄组在不同时间段的活跃度矩阵
        """
        return {
            TimeSlot.EARLY_MORNING: {
                UserAgeGroup.TEEN: 0.1,
                UserAgeGroup.YOUNG_ADULT: 0.2,
                UserAgeGroup.ADULT: 0.15,
                UserAgeGroup.MIDDLE_ADULT: 0.1,
                UserAgeGroup.MATURE_ADULT: 0.05,
                UserAgeGroup.SENIOR: 0.1
            },
            TimeSlot.DAWN: {
                UserAgeGroup.TEEN: 0.2,
                UserAgeGroup.YOUNG_ADULT: 0.3,
                UserAgeGroup.ADULT: 0.25,
                UserAgeGroup.MIDDLE_ADULT: 0.2,
                UserAgeGroup.MATURE_ADULT: 0.15,
                UserAgeGroup.SENIOR: 0.3
            },
            TimeSlot.MORNING: {
                UserAgeGroup.TEEN: 0.3,
                UserAgeGroup.YOUNG_ADULT: 0.4,
                UserAgeGroup.ADULT: 0.6,
                UserAgeGroup.MIDDLE_ADULT: 0.7,
                UserAgeGroup.MATURE_ADULT: 0.65,
                UserAgeGroup.SENIOR: 0.5
            },
            TimeSlot.NOON: {
                UserAgeGroup.TEEN: 0.4,
                UserAgeGroup.YOUNG_ADULT: 0.6,
                UserAgeGroup.ADULT: 0.8,
                UserAgeGroup.MIDDLE_ADULT: 0.85,
                UserAgeGroup.MATURE_ADULT: 0.8,
                UserAgeGroup.SENIOR: 0.6
            },
            TimeSlot.AFTERNOON: {
                UserAgeGroup.TEEN: 0.5,
                UserAgeGroup.YOUNG_ADULT: 0.7,
                UserAgeGroup.ADULT: 0.85,
                UserAgeGroup.MIDDLE_ADULT: 0.8,
                UserAgeGroup.MATURE_ADULT: 0.75,
                UserAgeGroup.SENIOR: 0.5
            },
            TimeSlot.EVENING: {
                UserAgeGroup.TEEN: 0.8,
                UserAgeGroup.YOUNG_ADULT: 0.9,
                UserAgeGroup.ADULT: 0.7,
                UserAgeGroup.MIDDLE_ADULT: 0.6,
                UserAgeGroup.MATURE_ADULT: 0.5,
                UserAgeGroup.SENIOR: 0.3
            },
            TimeSlot.NIGHT: {
                UserAgeGroup.TEEN: 0.7,
                UserAgeGroup.YOUNG_ADULT: 0.8,
                UserAgeGroup.ADULT: 0.5,
                UserAgeGroup.MIDDLE_ADULT: 0.4,
                UserAgeGroup.MATURE_ADULT: 0.3,
                UserAgeGroup.SENIOR: 0.1
            }
        }
    
    def _create_default_time_parameters(self) -> Dict:
        """
        创建默认的时间参数配置
        """
        return {
            TimeSlot.EARLY_MORNING: {
                'activation_rate': 0.05,
                'base_propagation_prob': 0.05,
                'interaction_intensity': 0.2
            },
            TimeSlot.DAWN: {
                'activation_rate': 0.1,
                'base_propagation_prob': 0.1,
                'interaction_intensity': 0.3
            },
            TimeSlot.MORNING: {
                'activation_rate': 0.2,
                'base_propagation_prob': 0.15,
                'interaction_intensity': 0.5
            },
            TimeSlot.NOON: {
                'activation_rate': 0.25,
                'base_propagation_prob': 0.2,
                'interaction_intensity': 0.6
            },
            TimeSlot.AFTERNOON: {
                'activation_rate': 0.3,
                'base_propagation_prob': 0.25,
                'interaction_intensity': 0.7
            },
            TimeSlot.EVENING: {
                'activation_rate': 0.4,
                'base_propagation_prob': 0.35,
                'interaction_intensity': 0.9
            },
            TimeSlot.NIGHT: {
                'activation_rate': 0.35,
                'base_propagation_prob': 0.3,
                'interaction_intensity': 0.8
            }
        }
    
    def _build_network(self) -> nx.Graph:
        """
        构建更真实的社交网络
        """
        # 使用BA无标度网络，更符合真实社交网络特征
        network = nx.barabasi_albert_graph(
            n=self.network_size, 
            m=5  # 每次添加的新节点连接数
        )
        return network
    
    def _initialize_users(self, predefined_distribution: Optional[Dict[UserAgeGroup, float]]) -> Dict:
        """
        初始化用户特征，包括年龄组
        """
        users = {}
        
        if predefined_distribution is None:
            # 默认年龄分布
            age_distribution = [
                (UserAgeGroup.TEEN, 0.08),
                (UserAgeGroup.YOUNG_ADULT, 0.25),
                (UserAgeGroup.ADULT, 0.25),
                (UserAgeGroup.MIDDLE_ADULT, 0.20),
                (UserAgeGroup.MATURE_ADULT, 0.15),
                (UserAgeGroup.SENIOR, 0.07)
            ]
        else:
            age_distribution = list(predefined_distribution.items())
        
        nodes = list(self.network.nodes())
        random.shuffle(nodes)
        
        idx = 0
        for age_group, ratio in age_distribution:
            count = int(self.network_size * ratio)
            for i in range(count):
                if idx < len(nodes):
                    users[nodes[idx]] = {
                        'age_group': age_group,
                        'activity_history': [],
                        'infection_time': None,
                        'degree': self.network.degree(nodes[idx])
                    }
                    idx += 1
        
        return users
    
    def _calculate_phase_boundaries(self) -> List[datetime]:
        """
        计算增长阶段的时间边界
        """
        boundaries = [self.start_time]
        current_time = self.start_time
        
        for phase, duration in self.growth_phases[:-1]:  # 除了最后一个阶段
            current_time += duration
            boundaries.append(current_time)
        
        return boundaries
    
    def _get_current_growth_phase(self, current_time: datetime) -> GrowthPhase:
        """
        根据当前时间获取增长阶段
        """
        for i, boundary in enumerate(self.phase_boundaries):
            if current_time < boundary:
                return self.growth_phases[i][0]
        
        # 如果超过了所有边界，返回最后一个阶段
        return self.growth_phases[-1][0]
    
    def _get_current_time_slot(self, current_time: datetime) -> TimeSlot:
        """
        根据当前时间获取时间段
        """
        hour = current_time.hour
        minute = current_time.minute
        time_fraction = hour + minute / 60.0
        
        if 0 <= time_fraction < 4:
            return TimeSlot.EARLY_MORNING
        elif 4 <= time_fraction < 8:
            return TimeSlot.DAWN
        elif 8 <= time_fraction < 12:
            return TimeSlot.MORNING
        elif 12 <= time_fraction < 14:
            return TimeSlot.NOON
        elif 14 <= time_fraction < 18:
            return TimeSlot.AFTERNOON
        elif 18 <= time_fraction < 21:
            return TimeSlot.EVENING
        else:
            return TimeSlot.NIGHT
    
    def _get_active_users(self, time_slot: TimeSlot, growth_phase: GrowthPhase) -> List:
        """
        根据时间段和增长阶段获取活跃用户
        """
        params = self.time_params[time_slot]
        active_users = []
        
        # 根据增长阶段调整基础激活率
        phase_multiplier = {
            GrowthPhase.SLOW_START: 0.7,
            GrowthPhase.RAPID_GROWTH: 1.0,
            GrowthPhase.STABLE: 0.9
        }[growth_phase]
        
        for node in self.network.nodes():
            age_group = self.users[node]['age_group']
            
            # 获取该年龄组在当前时间段的活跃度
            age_time_activity = self.age_time_activity[time_slot][age_group]
            
            # 计算综合激活概率
            base_activation_rate = params['activation_rate']
            activation_prob = base_activation_rate * age_time_activity * phase_multiplier
            
            if random.random() < activation_prob:
                active_users.append(node)
        
        return active_users
    
    def _calculate_propagation_probability(self, source_node: int, target_node: int, 
                                         time_slot: TimeSlot, growth_phase: GrowthPhase) -> float:
        """
        计算信息传播概率（考虑干预效果）
        """
        params = self.time_params[time_slot]
        
        # 基础传播概率
        base_prob = params['base_propagation_prob']
        
        # 增长阶段调整
        phase_multiplier = {
            GrowthPhase.SLOW_START: 0.6,
            GrowthPhase.RAPID_GROWTH: 1.2,
            GrowthPhase.STABLE: 0.8
        }[growth_phase]
        
        # 考虑发送方和接收方的年龄影响
        source_age_tendency = self.age_propagation_tendency[
            self.users[source_node]['age_group']
        ]
        target_age_tendency = self.age_propagation_tendency[
            self.users[target_node]['age_group']
        ]
        
        # 考虑节点度数的影响
        source_degree = self.users[source_node]['degree']
        target_degree = self.users[target_node]['degree']
        degree_factor = (source_degree * target_degree) ** 0.5 / 10.0
        
        # 考虑目标节点的干预效果
        intervention_effect = 1.0
        if self.node_intervention_status[target_node]['type'] == InterventionType.BLOCK:
            intervention_effect = 0.0  # 完全阻断
        elif self.node_intervention_status[target_node]['type'] == InterventionType.REDUCE:
            intervention_effect = max(0.0, 1.0 - self.node_intervention_status[target_node]['effectiveness'])
        elif self.node_intervention_status[target_node]['type'] == InterventionType.PROMOTE:
            intervention_effect = 1.0 + self.node_intervention_status[target_node]['effectiveness']
        
        # 综合传播概率
        final_prob = (base_prob * phase_multiplier * 
                     source_age_tendency * target_age_tendency * 
                     (1 + degree_factor * 0.1) * intervention_effect)
        
        # 限制在合理范围内
        return min(max(final_prob, 0.0), 1.0)
    
    def apply_intervention(self, node: int, intervention_type: InterventionType, 
                          duration_hours: int = 1, effectiveness: float = 0.5) -> float:
        """
        应用干预措施
        
        Args:
            node: 目标节点
            intervention_type: 干预类型
            duration_hours: 持续时间（小时）
            effectiveness: 干预效果（0-1）
            
        Returns:
            float: 干预成本
        """
        current_time_slot = self._get_current_time_slot(self.current_time)
        age_group = self.users[node]['age_group']
        
        # 计算干预成本
        cost_config = self.intervention_costs[intervention_type.value]
        base_cost = cost_config['base_cost']
        age_multiplier = cost_config['age_multipliers'][age_group]
        time_multiplier = cost_config['time_multipliers'][current_time_slot]
        
        total_cost = base_cost * age_multiplier * time_multiplier
        
        # 应用干预
        self.node_intervention_status[node] = {
            'type': intervention_type,
            'remaining_duration': int(duration_hours * 60 / 30),  # 转换为30分钟步数
            'effectiveness': effectiveness
        }
        
        # 记录干预
        self.intervention_history.append({
            'time': self.current_time,
            'node': node,
            'intervention_type': intervention_type.value,
            'cost': total_cost,
            'age_group': age_group.value,
            'time_slot': current_time_slot.value
        })
        
        return total_cost
    
    def seed_initial_information(self, seed_nodes: Optional[List[int]] = None, 
                               seed_ratio: float = 0.01,
                               high_degree_seeding: bool = True):
        """
        种子节点初始化信息传播
        """
        if seed_nodes is None:
            num_seeds = max(1, int(self.network_size * seed_ratio))
            
            if high_degree_seeding:
                # 优先选择高度数节点
                degrees = [(node, self.network.degree(node)) for node in self.network.nodes()]
                degrees.sort(key=lambda x: x[1], reverse=True)
                seed_nodes = [node for node, degree in degrees[:num_seeds]]
            else:
                seed_nodes = random.sample(list(self.network.nodes()), num_seeds)
        
        for node in seed_nodes:
            self.information_state[node] = 1
            self.users[node]['infection_time'] = self.current_time
            self.propagation_history.append({
                'time': self.current_time,
                'node': node,
                'action': 'seed',
                'growth_phase': self._get_current_growth_phase(self.current_time).value
            })
    
    def simulate_step(self) -> Dict:
        """
        执行一个时间步的传播模拟
        """
        current_time_slot = self._get_current_time_slot(self.current_time)
        current_growth_phase = self._get_current_growth_phase(self.current_time)
        active_users = self._get_active_users(current_time_slot, current_growth_phase)
        
        new_infections = 0
        newly_infected = []
        
        # 更新干预状态
        for node in self.network.nodes():
            if self.node_intervention_status[node]['remaining_duration'] > 0:
                self.node_intervention_status[node]['remaining_duration'] -= 1
            else:
                self.node_intervention_status[node] = {
                    'type': None,
                    'remaining_duration': 0,
                    'effectiveness': 0.0
                }
        
        # 激活用户进行信息传播
        for user in active_users:
            # 如果用户已感染信息，尝试传播给邻居
            if self.information_state[user] == 1:
                neighbors = list(self.network.neighbors(user))
                
                for neighbor in neighbors:
                    # 如果邻居未被感染，尝试传播
                    if self.information_state[neighbor] == 0:
                        prob = self._calculate_propagation_probability(
                            user, neighbor, current_time_slot, current_growth_phase
                        )
                        
                        if random.random() < prob:
                            self.information_state[neighbor] = 1
                            self.users[neighbor]['infection_time'] = self.current_time
                            newly_infected.append(neighbor)
                            self.propagation_history.append({
                                'time': self.current_time,
                                'node': neighbor,
                                'source': user,
                                'time_slot': current_time_slot.value,
                                'growth_phase': current_growth_phase.value,
                                'age_group': self.users[neighbor]['age_group'].value,
                                'source_age_group': self.users[user]['age_group'].value
                            })
                            new_infections += 1
        
        # 更新用户活动历史
        for user in active_users:
            self.users[user]['activity_history'].append({
                'time': self.current_time,
                'active': True,
                'time_slot': current_time_slot.value,
                'growth_phase': current_growth_phase.value
            })
        
        # 统计信息
        total_infected = sum(self.information_state.values())
        infection_rate = total_infected / self.network_size
        
        # 按年龄组统计感染情况
        age_group_infections = {age_group: 0 for age_group in UserAgeGroup}
        for node, state in self.information_state.items():
            if state == 1:
                age_group = self.users[node]['age_group']
                age_group_infections[age_group] += 1
        
        stats = {
            'time': self.current_time,
            'time_slot': current_time_slot.value,
            'growth_phase': current_growth_phase.value,
            'active_users': len(active_users),
            'new_infections': new_infections,
            'total_infected': total_infected,
            'infection_rate': infection_rate,
            'newly_infected_nodes': newly_infected,
            'age_group_infections': age_group_infections.copy()
        }
        
        return stats
    
    def get_state(self) -> np.ndarray:
        """
        获取当前环境状态（用于强化学习）
        """
        # 特征包括：感染率、活跃用户数、当前时间槽、增长阶段、干预状态等
        infection_rate = sum(self.information_state.values()) / self.network_size
        active_users = len(self._get_active_users(
            self._get_current_time_slot(self.current_time),
            self._get_current_growth_phase(self.current_time)
        ))
        
        # 简化的状态表示
        state = np.array([
            infection_rate,
            active_users / self.network_size,  # 归一化活跃用户比例
            self._get_current_time_slot(self.current_time).value.__hash__() % 7 / 7.0,  # 时间槽编码
            self._get_current_growth_phase(self.current_time).value.__hash__() % 3 / 3.0,  # 阶段编码
            len(self.intervention_history) / self.max_interventions  # 干预使用比例
        ])
        
        return state
    
    def reset(self):
        """
        重置环境
        """
        self.current_time = self.start_time
        self.information_state = {node: 0 for node in self.network.nodes()}
        self.propagation_history = []
        self.intervention_history = []
        self.node_intervention_status = {node: {
            'type': None,
            'remaining_duration': 0,
            'effectiveness': 0.0
        } for node in self.network.nodes()}

class DQN(nn.Module):
    """
    深度Q网络
    """
    
    def __init__(self, state_size: int, action_size: int, hidden_size: int = 128):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(state_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, hidden_size)
        self.fc4 = nn.Linear(hidden_size, action_size)
        self.dropout = nn.Dropout(0.2)
    
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = F.relu(self.fc3(x))
        x = self.dropout(x)
        return self.fc4(x)

class DQNAgent:
    """
    DQN智能体
    """
    
    def __init__(self, state_size: int, action_size: int, lr: float = 0.001):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = []  # 经验回放
        self.epsilon = 1.0  # 探索率
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = lr
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 神经网络
        self.q_network = DQN(state_size, action_size).to(self.device)
        self.target_network = DQN(state_size, action_size).to(self.device)
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=lr)
        
        # 更新目标网络
        self.update_target_network()
    
    def update_target_network(self):
        """更新目标网络"""
        self.target_network.load_state_dict(self.q_network.state_dict())
    
    def remember(self, state, action, reward, next_state, done):
        """存储经验"""
        self.memory.append((state, action, reward, next_state, done))
        if len(self.memory) > 10000:  # 限制记忆大小
            self.memory.pop(0)
    
    def act(self, state, available_actions):
        """选择动作"""
        if np.random.random() <= self.epsilon:
            return random.choice(available_actions)
        
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        q_values = self.q_network(state_tensor)
        
        # 只考虑可用动作
        masked_q_values = q_values.clone()
        for i in range(self.action_size):
            if i not in available_actions:
                masked_q_values[0][i] = float('-inf')
        
        return masked_q_values.argmax().item()
    
    def replay(self, batch_size: int = 32):
        """经验回放训练"""
        if len(self.memory) < batch_size:
            return
        
        batch = random.sample(self.memory, batch_size)
        states = torch.FloatTensor([e[0] for e in batch]).to(self.device)
        actions = torch.LongTensor([e[1] for e in batch]).to(self.device)
        rewards = torch.FloatTensor([e[2] for e in batch]).to(self.device)
        next_states = torch.FloatTensor([e[3] for e in batch]).to(self.device)
        dones = torch.BoolTensor([e[4] for e in batch]).to(self.device)
        
        current_q_values = self.q_network(states).gather(1, actions.unsqueeze(1))
        next_q_values = self.target_network(next_states).max(1)[0].detach()
        target_q_values = rewards + (0.95 * next_q_values * ~dones)
        
        loss = F.mse_loss(current_q_values.squeeze(), target_q_values)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

def train_intervention_agent(env: InterventionEnvironment, episodes: int = 1000):
    """
    训练干预智能体
    """
    state_size = 5  # 感染率、活跃用户比例、时间槽、阶段、干预使用比例
    action_size = env.network_size * 3  # 每个节点3种干预类型
    
    agent = DQNAgent(state_size, action_size)
    
    total_rewards = []
    
    for episode in range(episodes):
        env.reset()
        state = env.get_state()
        total_reward = 0
        done = False
        step_count = 0
        
        # 初始化传播
        env.seed_initial_information(seed_ratio=env.seed_ratio)
        
        while not done and step_count < 240:  # 限制每回合步数
            # 获取可用动作（选择未干预的节点）
            available_nodes = [node for node in env.network.nodes() 
                             if env.node_intervention_status[node]['remaining_duration'] <= 0]
            
            # 限制可选节点数量
            if len(available_nodes) > 50:
                available_nodes = random.sample(available_nodes, 50)
            
            available_actions = []
            for node in available_nodes:
                for intervention_type in InterventionType:
                    action = node * 3 + list(InterventionType).index(intervention_type)
                    available_actions.append(action)
            
            # 限制动作数量
            if len(available_actions) > 100:
                available_actions = random.sample(available_actions, 100)
            
            if available_actions:
                action = agent.act(state, available_actions)
                
                # 解析动作
                node_idx = action // 3
                intervention_idx = action % 3
                intervention_type = list(InterventionType)[intervention_idx]
                
                # 执行干预
                cost = env.apply_intervention(node_idx, intervention_type, duration_hours=2, effectiveness=0.7)
                
                # 模拟一步传播
                stats = env.simulate_step()
                
                # 计算奖励
                # 奖励 = -传播数量 - 成本 + 信息控制效果
                reward = -stats['new_infections'] * 0.1 - cost * 0.01 + (0.5 - stats['infection_rate']) * 10
                
                next_state = env.get_state()
                
                agent.remember(state, action, reward, next_state, False)
                state = next_state
                total_reward += reward
            else:
                # 没有可用动作时继续模拟
                stats = env.simulate_step()
                reward = -stats['new_infections'] * 0.1 + (0.5 - stats['infection_rate']) * 10
                next_state = env.get_state()
                agent.remember(state, 0, reward, next_state, False)
                state = next_state
                total_reward += reward
            
            step_count += 1
            
            # 检查是否结束
            if step_count >= 240 or len(env.intervention_history) >= env.max_interventions:
                done = True
        
        total_rewards.append(total_reward)
        
        # 训练网络
        if len(agent.memory) > 32:
            agent.replay(32)
        
        # 更新目标网络
        if episode % 100 == 0:
            agent.update_target_network()
        
        if episode % 100 == 0:
            print(f"Episode {episode}, Average Reward: {np.mean(total_rewards[-100:]) if len(total_rewards) >= 100 else np.mean(total_rewards):.2f}")
    
    return agent

def evaluate_strategy(env: InterventionEnvironment, strategy_func, strategy_name: str):
    """
    评估特定策略
    
    Args:
        env: 环境
        strategy_func: 策略函数
        strategy_name: 策略名称
    
    Returns:
        Dict: 评估结果
    """
    env.reset()
    env.seed_initial_information(seed_ratio=env.seed_ratio)
    
    results = {
        'strategy_name': strategy_name,
        'total_infected': 0,
        'total_cost': 0,
        'intervention_count': 0,
        'final_infection_rate': 0,
        'infection_trajectory': [],
        'cost_trajectory': [],
        'intervention_trajectory': [],
        'network_metrics': {},
        'age_group_analysis': {},
        'time_slot_analysis': {}
    }
    
    step_count = 0
    while step_count < 240:
        # 执行策略
        cost = strategy_func(env)
        results['total_cost'] += cost
        if cost > 0:
            results['intervention_count'] += 1
            results['intervention_trajectory'].append(len(env.intervention_history))
        else:
            results['intervention_trajectory'].append(len(env.intervention_history))
        
        # 模拟一步传播
        stats = env.simulate_step()
        results['infection_trajectory'].append(stats['infection_rate'])
        results['cost_trajectory'].append(results['total_cost'])
        
        step_count += 1
    
    results['total_infected'] = sum(env.information_state.values())
    results['final_infection_rate'] = sum(env.information_state.values()) / env.network_size
    
    # 计算网络指标
    results['network_metrics'] = {
        'clustering_coefficient': nx.average_clustering(env.network),
        'average_path_length': nx.average_shortest_path_length(env.network) if nx.is_connected(env.network) else float('inf'),
        'diameter': nx.diameter(env.network) if nx.is_connected(env.network) else -1
    }
    
    # 年龄组分析
    age_infection_counts = {age_group: 0 for age_group in UserAgeGroup}
    for node, state in env.information_state.items():
        if state == 1:
            age_group = env.users[node]['age_group']
            age_infection_counts[age_group] += 1
    
    results['age_group_analysis'] = {
        'infections_by_age': age_infection_counts,
        'infection_rates_by_age': {age: count / sum(1 for n in env.users.values() if n['age_group'] == age) 
                                  for age, count in age_infection_counts.items()}
    }
    
    return results

def random_strategy(env: InterventionEnvironment):
    """随机策略"""
    if random.random() < 0.1 and len(env.intervention_history) < env.max_interventions:  # 10%概率干预
        available_nodes = [node for node in env.network.nodes() 
                         if env.node_intervention_status[node]['remaining_duration'] <= 0]
        
        if available_nodes:
            node_idx = random.choice(available_nodes)
            intervention_type = random.choice(list(InterventionType))
            return env.apply_intervention(node_idx, intervention_type, duration_hours=2, effectiveness=0.7)
    return 0

def greedy_strategy(env: InterventionEnvironment):
    """贪心策略 - 选择度数最高的节点进行干预"""
    if len(env.intervention_history) < env.max_interventions:
        available_nodes = [node for node in env.network.nodes() 
                         if env.node_intervention_status[node]['remaining_duration'] <= 0]
        
        if available_nodes:
            # 选择度数最高的节点
            degrees = [(node, env.users[node]['degree']) for node in available_nodes]
            degrees.sort(key=lambda x: x[1], reverse=True)
            node_idx = degrees[0][0]
            intervention_type = random.choice(list(InterventionType))
            return env.apply_intervention(node_idx, intervention_type, duration_hours=2, effectiveness=0.7)
    return 0

def no_intervention_strategy(env: InterventionEnvironment):
    """无干预策略"""
    return 0

def evaluate_all_strategies(env: InterventionEnvironment, agent: Optional[DQNAgent] = None):
    """
    评估所有策略
    """
    strategies = [
        ('DQN Agent', lambda e: dqn_agent_strategy(e, agent) if agent else no_intervention_strategy(e)),
        ('Random', random_strategy),
        ('Greedy', greedy_strategy),
        ('No Intervention', no_intervention_strategy),
        ('Early Intervention', early_intervention_strategy),
        ('Late Intervention', late_intervention_strategy),
        ('High-Degree Intervention', high_degree_intervention_strategy)
    ]
    
    all_results = []
    for name, strategy_func in strategies:
        print(f"Evaluating {name} strategy...")
        results = evaluate_strategy(env, strategy_func, name)
        all_results.append(results)
    
    return all_results

def dqn_agent_strategy(env: InterventionEnvironment, agent: DQNAgent):
    """DQN智能体策略"""
    state = env.get_state()
    
    # 获取可用动作
    available_nodes = [node for node in env.network.nodes() 
                     if env.node_intervention_status[node]['remaining_duration'] <= 0]
    
    if len(available_nodes) > 50:
        available_nodes = random.sample(available_nodes, 50)
    
    available_actions = []
    for node in available_nodes:
        for intervention_type in InterventionType:
            action = node * 3 + list(InterventionType).index(intervention_type)
            available_actions.append(action)
    
    if len(available_actions) > 100:
        available_actions = random.sample(available_actions, 100)
    
    if available_actions:
        action = agent.act(state, available_actions)
        
        # 解析动作
        node_idx = action // 3
        intervention_idx = action % 3
        intervention_type = list(InterventionType)[intervention_idx]
        
        # 执行干预
        return env.apply_intervention(node_idx, intervention_type, duration_hours=2, effectiveness=0.7)
    
    return 0

def early_intervention_strategy(env: InterventionEnvironment):
    """早期干预策略 - 在感染率较低时积极干预"""
    current_infection_rate = sum(env.information_state.values()) / env.network_size
    if current_infection_rate < 0.1 and len(env.intervention_history) < env.max_interventions:
        available_nodes = [node for node in env.network.nodes() 
                         if env.node_intervention_status[node]['remaining_duration'] <= 0]
        
        if available_nodes:
            node_idx = random.choice(available_nodes)
            intervention_type = InterventionType.BLOCK
            return env.apply_intervention(node_idx, intervention_type, duration_hours=2, effectiveness=0.7)
    return 0

def late_intervention_strategy(env: InterventionEnvironment):
    """晚期干预策略 - 在感染率较高时干预"""
    current_infection_rate = sum(env.information_state.values()) / env.network_size
    if current_infection_rate > 0.5 and len(env.intervention_history) < env.max_interventions:
        available_nodes = [node for node in env.network.nodes() 
                         if env.node_intervention_status[node]['remaining_duration'] <= 0]
        
        if available_nodes:
            node_idx = random.choice(available_nodes)
            intervention_type = InterventionType.REDUCE
            return env.apply_intervention(node_idx, intervention_type, duration_hours=2, effectiveness=0.7)
    return 0

def high_degree_intervention_strategy(env: InterventionEnvironment):
    """高度数节点干预策略"""
    if len(env.intervention_history) < env.max_interventions:
        available_nodes = [node for node in env.network.nodes() 
                         if env.node_intervention_status[node]['remaining_duration'] <= 0]
        
        if available_nodes:
            # 选择度数最高的节点
            degrees = [(node, env.users[node]['degree']) for node in available_nodes]
            degrees.sort(key=lambda x: x[1], reverse=True)
            node_idx = degrees[0][0]
            intervention_type = InterventionType.REDUCE
            return env.apply_intervention(node_idx, intervention_type, duration_hours=2, effectiveness=0.7)
    return 0

def create_comprehensive_comparison_table(results_list: List[Dict]) -> pd.DataFrame:
    """
    创建全面的对比表格
    """
    data = []
    for result in results_list:
        data.append({
            'Strategy': result['strategy_name'],
            'Total Infected': result['total_infected'],
            'Final Infection Rate': f"{result['final_infection_rate']:.4f}",
            'Total Cost': f"{result['total_cost']:.2f}",
            'Interventions': result['intervention_count'],
            'Cost per Intervention': f"{result['total_cost']/max(1, result['intervention_count']):.2f}",
            'Infection Reduction': f"{(1 - result['final_infection_rate']):.4f}",
            'Clustering Coeff': f"{result['network_metrics']['clustering_coefficient']:.4f}",
            'Avg Path Length': f"{result['network_metrics']['average_path_length']:.2f}",
            'Diameter': result['network_metrics']['diameter']
        })
    
    df = pd.DataFrame(data)
    return df

def create_age_group_analysis_table(results_list: List[Dict]) -> pd.DataFrame:
    """
    创建年龄组分析表格
    """
    age_groups = [group.value for group in UserAgeGroup]
    data = []
    
    for result in results_list:
        row = {'Strategy': result['strategy_name']}
        for age_group in age_groups:
            age_enum = UserAgeGroup(age_group)
            rate = result['age_group_analysis']['infection_rates_by_age'].get(age_enum, 0)
            row[f'{age_group}_rate'] = f"{rate:.4f}"
        data.append(row)
    
    df = pd.DataFrame(data)
    return df

def visualize_comprehensive_results(results_list: List[Dict]):
    """
    综合可视化结果
    """
    # 1. 创建对比表格
    df = create_comprehensive_comparison_table(results_list)
    print("\nStrategy Comparison Table:")
    print(df.to_string(index=False))
    
    # 2. 年龄组分析表格
    age_df = create_age_group_analysis_table(results_list)
    print("\nAge Group Infection Rate Analysis:")
    print(age_df.to_string(index=False))
    
    # 3. 综合对比图 - 分开保存
    strategies = [r['strategy_name'] for r in results_list]
    final_rates = [r['final_infection_rate'] for r in results_list]
    total_costs = [r['total_cost'] for r in results_list]
    intervention_counts = [r['intervention_count'] for r in results_list]
    
    # 图1: 最终感染率对比
    plt.figure(figsize=(12, 6))
    bars1 = plt.bar(strategies, final_rates, color=plt.cm.tab10(range(len(strategies))), alpha=0.7)
    plt.title('Final Infection Rate Comparison', fontsize=14, fontweight='bold')
    plt.ylabel('Infection Rate')
    plt.grid(axis='y', alpha=0.3)
    plt.xticks(rotation=45)
    
    # 添加数值标签
    for bar, rate in zip(bars1, final_rates):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01, 
                f'{rate:.3f}', ha='center', va='bottom', fontsize=8)
    
    plt.tight_layout()
    plt.savefig('final_infection_rate_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 图2: 总成本对比
    plt.figure(figsize=(12, 6))
    bars2 = plt.bar(strategies, total_costs, color=plt.cm.tab10(range(len(strategies))), alpha=0.7)
    plt.title('Total Intervention Cost Comparison', fontsize=14, fontweight='bold')
    plt.ylabel('Total Cost')
    plt.grid(axis='y', alpha=0.3)
    plt.xticks(rotation=45)
    
    # 添加数值标签
    for bar, cost in zip(bars2, total_costs):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                f'{cost:.1f}', ha='center', va='bottom', fontsize=8)
    
    plt.tight_layout()
    plt.savefig('total_cost_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 图3: 干预次数对比
    plt.figure(figsize=(12, 6))
    bars3 = plt.bar(strategies, intervention_counts, color=plt.cm.tab10(range(len(strategies))), alpha=0.7)
    plt.title('Number of Interventions Comparison', fontsize=14, fontweight='bold')
    plt.ylabel('Number of Interventions')
    plt.grid(axis='y', alpha=0.3)
    plt.xticks(rotation=45)
    
    # 添加数值标签
    for bar, count in zip(bars3, intervention_counts):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5, 
                f'{count}', ha='center', va='bottom', fontsize=8)
    
    plt.tight_layout()
    plt.savefig('intervention_count_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 图4: 感染率降低对比
    reduction = [1 - r['final_infection_rate'] for r in results_list]
    plt.figure(figsize=(12, 6))
    bars4 = plt.bar(strategies, reduction, color=plt.cm.tab10(range(len(strategies))), alpha=0.7)
    plt.title('Infection Rate Reduction Comparison', fontsize=14, fontweight='bold')
    plt.ylabel('Infection Rate Reduction')
    plt.grid(axis='y', alpha=0.3)
    plt.xticks(rotation=45)
    
    # 添加数值标签
    for bar, red in zip(bars4, reduction):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01, 
                f'{red:.3f}', ha='center', va='bottom', fontsize=8)
    
    plt.tight_layout()
    plt.savefig('infection_reduction_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 图5: 感染率轨迹对比
    plt.figure(figsize=(14, 8))
    for result in results_list:
        plt.plot(result['infection_trajectory'], label=result['strategy_name'], linewidth=2)
    
    plt.title('Infection Rate Trajectory Comparison Over Time', fontsize=16, fontweight='bold')
    plt.xlabel('Time Steps', fontsize=12)
    plt.ylabel('Infection Rate', fontsize=12)
    plt.legend(fontsize=10, bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('infection_trajectory_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 图6: 年龄组感染率热力图
    age_groups = [group.value for group in UserAgeGroup]
    age_matrix = np.zeros((len(strategies), len(age_groups)))
    
    for i, result in enumerate(results_list):
        for j, age_group in enumerate(age_groups):
            age_enum = UserAgeGroup(age_group)
            rate = result['age_group_analysis']['infection_rates_by_age'].get(age_enum, 0)
            age_matrix[i, j] = rate
    
    plt.figure(figsize=(12, 8))
    sns.heatmap(age_matrix, 
                xticklabels=age_groups, 
                yticklabels=strategies,
                annot=True, 
                fmt='.3f',
                cmap='RdYlGn_r',
                center=0.5,
                cbar_kws={'label': 'Infection Rate'})
    plt.title('Infection Rate by Age Group and Strategy', fontsize=16, fontweight='bold')
    plt.xlabel('Age Group', fontsize=12)
    plt.ylabel('Strategy', fontsize=12)
    plt.tight_layout()
    plt.savefig('age_group_heatmap.png', dpi=300, bbox_inches='tight')
    plt.show()

def perform_ablation_study(env: InterventionEnvironment):
    """
    消融实验
    """
    print("Performing Ablation Study...")
    
    # 测试不同干预类型的影响
    intervention_types = [InterventionType.BLOCK, InterventionType.REDUCE, InterventionType.PROMOTE]
    ablation_results = []
    
    for int_type in intervention_types:
        env.reset()
        env.seed_initial_information(seed_ratio=env.seed_ratio)
        
        results = {
            'intervention_type': int_type.value,
            'total_infected': 0,
            'total_cost': 0,
            'final_infection_rate': 0,
            'intervention_count': 0
        }
        
        step_count = 0
        while step_count < 240 and len(env.intervention_history) < env.max_interventions:
            # 每10步进行一次干预
            if step_count % 10 == 0:
                available_nodes = [node for node in env.network.nodes() 
                                 if env.node_intervention_status[node]['remaining_duration'] <= 0]
                
                if available_nodes:
                    node_idx = random.choice(available_nodes)
                    cost = env.apply_intervention(node_idx, int_type, duration_hours=2, effectiveness=0.7)
                    results['total_cost'] += cost
                    results['intervention_count'] += 1
            
            # 模拟一步传播
            stats = env.simulate_step()
            step_count += 1
        
        results['total_infected'] = sum(env.information_state.values())
        results['final_infection_rate'] = sum(env.information_state.values()) / env.network_size
        ablation_results.append(results)
    
    # 创建消融实验表格
    ablation_df = pd.DataFrame(ablation_results)
    print("\nAblation Study Results:")
    print(ablation_df.to_string(index=False))
    
    # 可视化消融实验结果
    plt.figure(figsize=(12, 6))
    
    plt.subplot(1, 2, 1)
    plt.bar(ablation_df['intervention_type'], ablation_df['final_infection_rate'], 
            color=['red', 'blue', 'green'], alpha=0.7)
    plt.title('Final Infection Rate by Intervention Type', fontsize=14, fontweight='bold')
    plt.ylabel('Final Infection Rate')
    plt.xlabel('Intervention Type')
    for i, v in enumerate(ablation_df['final_infection_rate']):
        plt.text(i, v + 0.01, f'{v:.3f}', ha='center', va='bottom')
    
    plt.subplot(1, 2, 2)
    plt.bar(ablation_df['intervention_type'], ablation_df['total_cost'], 
            color=['green', 'orange', 'red'], alpha=0.7)
    plt.title('Total Cost by Intervention Type', fontsize=14, fontweight='bold')
    plt.ylabel('Total Cost')
    plt.xlabel('Intervention Type')
    for i, v in enumerate(ablation_df['total_cost']):
        plt.text(i, v + 1, f'{v:.1f}', ha='center', va='bottom')
    
    plt.tight_layout()
    plt.savefig('ablation_study.png', dpi=300, bbox_inches='tight')
    plt.show()

def perform_sensitivity_analysis(env: InterventionEnvironment):
    """
    参数敏感性分析
    """
    print("Performing Sensitivity Analysis...")
    
    # 测试不同种子比例的影响
    seed_ratios = [0.001, 0.005, 0.01, 0.02, 0.05]
    sensitivity_results = []
    
    for seed_ratio in seed_ratios:
        env.seed_ratio = seed_ratio
        env.reset()
        env.seed_initial_information(seed_ratio=seed_ratio)
        
        results = {
            'seed_ratio': seed_ratio,
            'total_infected': 0,
            'final_infection_rate': 0
        }
        
        step_count = 0
        while step_count < 240:
            # 模拟一步传播
            stats = env.simulate_step()
            step_count += 1
        
        results['total_infected'] = sum(env.information_state.values())
        results['final_infection_rate'] = sum(env.information_state.values()) / env.network_size
        sensitivity_results.append(results)
    
    # 创建敏感性分析表格
    sensitivity_df = pd.DataFrame(sensitivity_results)
    print("\nSensitivity Analysis Results:")
    print(sensitivity_df.to_string(index=False))
    
    # 可视化敏感性分析结果
    plt.figure(figsize=(12, 6))
    
    plt.subplot(1, 2, 1)
    plt.plot(sensitivity_df['seed_ratio'], sensitivity_df['final_infection_rate'], 
             'bo-', linewidth=2, markersize=8)
    plt.title('Final Infection Rate vs Seed Ratio', fontsize=14, fontweight='bold')
    plt.xlabel('Seed Ratio')
    plt.ylabel('Final Infection Rate')
    plt.grid(True, alpha=0.3)
    
    plt.subplot(1, 2, 2)
    plt.plot(sensitivity_df['seed_ratio'], sensitivity_df['total_infected'], 
             'ro-', linewidth=2, markersize=8)
    plt.title('Total Infected vs Seed Ratio', fontsize=14, fontweight='bold')
    plt.xlabel('Seed Ratio')
    plt.ylabel('Total Infected')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('sensitivity_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()

def perform_network_analysis(env: InterventionEnvironment, results_list: List[Dict]):
    """
    网络结构分析
    """
    print("Performing Network Analysis...")
    
    # 分析网络指标
    network_metrics = []
    for result in results_list:
        network_metrics.append({
            'Strategy': result['strategy_name'],
            'Clustering Coeff': result['network_metrics']['clustering_coefficient'],
            'Avg Path Length': result['network_metrics']['average_path_length'],
            'Diameter': result['network_metrics']['diameter']
        })
    
    network_df = pd.DataFrame(network_metrics)
    print("\nNetwork Metrics Analysis:")
    print(network_df.to_string(index=False))
    
    # 可视化网络指标
    strategies = network_df['Strategy']
    clustering_coeffs = network_df['Clustering Coeff']
    avg_path_lengths = network_df['Avg Path Length']
    
    plt.figure(figsize=(14, 6))
    
    plt.subplot(1, 2, 1)
    bars1 = plt.bar(strategies, clustering_coeffs, color=plt.cm.tab10(range(len(strategies))), alpha=0.7)
    plt.title('Clustering Coefficient by Strategy', fontsize=14, fontweight='bold')
    plt.ylabel('Clustering Coefficient')
    plt.grid(axis='y', alpha=0.3)
    plt.xticks(rotation=45)
    
    for bar, coeff in zip(bars1, clustering_coeffs):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.001, 
                f'{coeff:.3f}', ha='center', va='bottom', fontsize=8)
    
    plt.subplot(1, 2, 2)
    bars2 = plt.bar(strategies, avg_path_lengths, color=plt.cm.tab10(range(len(strategies))), alpha=0.7)
    plt.title('Average Path Length by Strategy', fontsize=14, fontweight='bold')
    plt.ylabel('Average Path Length')
    plt.grid(axis='y', alpha=0.3)
    plt.xticks(rotation=45)
    
    for bar, length in zip(bars2, avg_path_lengths):
        if length != float('inf'):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                    f'{length:.1f}', ha='center', va='bottom', fontsize=8)
    
    plt.tight_layout()
    plt.savefig('network_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()

def main():
    """
    主函数 - 运行完整的传播干预研究
    """
    print("Starting Time-Heterogeneous Network Information Propagation Intervention Study...")
    print(f"Network Size: 1000 nodes")
    print(f"Training Episodes: 500")
    print(f"Max Interventions: 100")
    print("-" * 80)
    
    # 创建环境
    env = InterventionEnvironment(
        network_size=1000,
        start_time=datetime(2025, 11, 14, 0, 0),
        simulation_days=5,
        max_interventions=100
    )
    
    # 训练智能体
    print("Training DQN Agent...")
    agent = train_intervention_agent(env, episodes=500)  # 减少训练轮数以加快演示
    print("Training completed!")
    
    # 评估所有策略
    print("Evaluating all strategies...")
    all_results = evaluate_all_strategies(env, agent)
    
    # 综合可视化结果
    visualize_comprehensive_results(all_results)
    
    # 网络分析
    perform_network_analysis(env, all_results)
    
    # 消融实验
    perform_ablation_study(env)
    
    # 参数敏感性分析
    perform_sensitivity_analysis(env)
    
    print("\nAll experiments completed successfully!")

if __name__ == "__main__":
    main()